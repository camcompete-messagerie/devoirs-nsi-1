###---Exercice 1---###
def noeud(nom, fg = None, fd = None) :
    return {'racine': nom, 'fg' : fg, 'fd': fd}
# création des noeuds
k = noeud('k')
f = noeud('f')
e = noeud('e', k, None)
b = noeud('b', e, f)
m = noeud('m')
j = noeud('j', m, None)
i = noeud('i')
d = noeud('d', i, j)
h = noeud('h')
c = noeud('c', None, h)
a = noeud('a', c, d)
racine = noeud('r', a, b)
# création de l’arbre
def construit(arbre) :
    if arbre == None :
        return []
    else:
        return [arbre['racine'],construit(arbre['fg']),construit(arbre['fd'])]

arbre=construit(racine)
if __name__=="__main__":
    print(arbre)


###---Exercice 2---###
deux=noeud("2",None,None)
six=noeud("6",None,None)
soustraction=noeud("-",deux,six)
cinq=noeud("5",None,None)
multiplication=noeud("*",soustraction,cinq)
arbre_arithmetique=construit(multiplication)
if __name__=="__main__":
    print(arbre_arithmetique)


###---Exercice 3---###
def hauteur(arbre):
    """
    Input : arbre ---> arbre binaire représenté comme tableau de tableaux ([racine,[fg],[fd]] avec fg=[noeud,[fg],[fd]]
    Ouput : ---> retourne la hauteur de l'arbre (type(int))
    """
    if arbre==[] or arbre==None or arbre==[None]:
        return -1
    else:
        h1=1+hauteur(arbre[1])
        h2=1+hauteur(arbre[2])
        return max(h1,h2)

if __name__=="__main__":
    print("Hauteur \"arbre\" :",hauteur(arbre))
    print("Hauteur \"arbre_arithmetique\" :",hauteur(arbre_arithmetique))