from Files_classe import File
from Exs_ArbresBinairesRecursifs_Jules_Rollier import arbre


###-----Exercice 1-----###
def parcoursLargeur(arbre):
    f=File()
    liste=[]
    f.enfiler(arbre)
    while not f.vide():
        tmp=f.defiler()
        liste.append(tmp[0])
        if tmp[1]!=[]:
            f.enfiler(tmp[1])
        if tmp[2]!=[]:
            f.enfiler(tmp[2])
    return liste

print("Parcours en largeur de arbre :")
print(parcoursLargeur(arbre))


###-----Exercice 2-----###
def parcoursProfondeurPrefixe(arbre):
    if arbre!=[]:
        print(arbre[0],end=" ; ")
        parcoursProfondeurPrefixe(arbre[1])
        parcoursProfondeurPrefixe(arbre[2])

print()
print("Parcours en profondeur préfixe de arbre :")
parcoursProfondeurPrefixe(arbre)


def parcoursProfondeurInfixe(arbre):
    if arbre!=[]:
        parcoursProfondeurInfixe(arbre[1])
        print(arbre[0],end=" ; ")
        parcoursProfondeurInfixe(arbre[2])

print()
print("Parcours en profondeur infixe de arbre :")
parcoursProfondeurInfixe(arbre)


def parcoursProfondeurSuffixe(arbre):
    if arbre!=[]:
        parcoursProfondeurSuffixe(arbre[1])
        parcoursProfondeurSuffixe(arbre[2])
        print(arbre[0],end=" ; ")

print()
print("Parcours en profondeur suffixe de arbre :")
parcoursProfondeurSuffixe(arbre)