class File:
    def __init__(self): 
        self.file=[]
 
    def vide(self): 
        if self.file==[]:
            return True
        return False
 
    def defiler(self): 
        return self.file.pop(0)
 
    def enfiler(self,x): 
        self.file.append(x)
    
    def __str__(self):
        L="<--- "
        for ele in self.file:
            L=L+str(ele)+" ; "
        return L+"<---"
    
    def remplissage(self):
        return len(self.file)
    
    def tete(self):
        return self.file[0]
            
if __name__=="__main__":
    f=File()
    f.enfiler(0)
    f.enfiler(2)
    f.enfiler(4)
    f.enfiler(6)
    f.enfiler(8)
    print(f)
    car=f.defiler()
    print(car)
    print(f.vide())
    print(f.remplissage())
    print(f.tete())
