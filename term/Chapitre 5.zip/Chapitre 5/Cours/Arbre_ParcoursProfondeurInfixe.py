from Exs_ArbresBinairesRecursifs_Jules_Rollier import arbre

def parcoursProfondeurInfixe(arbre):
    if arbre!=[]:
        parcoursProfondeurInfixe(arbre[1])
        print(arbre[0],end=" ; ")
        parcoursProfondeurInfixe(arbre[2])

if __name__=="__main__":
    print("Parcours en profondeur infixe de arbre :")
    parcoursProfondeurInfixe(arbre)