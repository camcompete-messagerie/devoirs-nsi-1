from Exs_ArbresBinairesRecursifs_Jules_Rollier import arbre

def parcoursProfondeurSuffixe(arbre):
    if arbre!=[]:
        parcoursProfondeurSuffixe(arbre[1])
        parcoursProfondeurSuffixe(arbre[2])
        print(arbre[0],end=" ; ")

if __name__=="__main__":
    print("Parcours en profondeur suffixe de arbre :")
    parcoursProfondeurSuffixe(arbre)