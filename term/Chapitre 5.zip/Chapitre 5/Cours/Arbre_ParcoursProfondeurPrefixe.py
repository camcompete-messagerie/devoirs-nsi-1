from Exs_ArbresBinairesRecursifs_Jules_Rollier import arbre

def parcoursProfondeurPrefixe(arbre):
    if arbre!=[]:
        print(arbre[0],end=" ; ")
        parcoursProfondeurPrefixe(arbre[1])
        parcoursProfondeurPrefixe(arbre[2])

if __name__=="__main__":
    print("Parcours en profondeur préfixe de arbre :")
    parcoursProfondeurPrefixe(arbre)