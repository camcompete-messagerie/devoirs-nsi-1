def creation_arbre(r,profondeur):
    ''' r : la racine (str ou int). la profondeur de l'arbre (int)'''
    Arbre = [r]+[None for i in range(2**(profondeur+1)-2)]
    return Arbre

def insertion_noeud(arbre,n,fg,fd):
    '''Insére les noeuds et leurs enfants dans l'arbre'''
    indice = arbre.index(n)
    arbre[2*indice+1] = fg
    arbre[2*indice+2] = fd

def parent(arbre,p):
    if p in arbre:
        indice = arbre.index(p)
    if indice%2 == 0:
        return arbre[(indice-2)//2]
    else:
        return arbre[(indice-1)//2]


###----------Exercice 1----------###
arbre = creation_arbre("r",5)
# ajout des noeuds par niveau de gauche à droite
insertion_noeud(arbre,"r","a","b")
insertion_noeud(arbre,"a","c","d")
insertion_noeud(arbre,"b","e","f")
insertion_noeud(arbre,"c",None,"h")
insertion_noeud(arbre,"d","i","j")
insertion_noeud(arbre,"e","k",None)
insertion_noeud(arbre,"f",None,None)
insertion_noeud(arbre,"h",None,None)
insertion_noeud(arbre,"i",None,None)
insertion_noeud(arbre,"j","m",None)
insertion_noeud(arbre,"k",None,None)
insertion_noeud(arbre,"m",None,None)
#pour vérifier
print(len(arbre))
print(arbre)
print()
print("Parent du noeud \"e\" :",parent(arbre,"e"))


###----------Exercice 3----------###
print("\n------------------------------Exercice 3------------------------------")

# 1)
def est_vide(arbre):
    return arbre==[]

print("Arbre vide ? :",est_vide(arbre))

# 2)
def enfants_noeud(arbre,noeud):
    if noeud in arbre:
        indice=arbre.index(noeud)
        return arbre[(indice+1)*2-1],arbre[(indice+1)*2]

print("Enfants du noeud \"a\" dans arbre :",enfants_noeud(arbre,"a"))

# 3)
def fils_gauche(arbre,noeud):
    if noeud in arbre:
        indice=arbre.index(noeud)
        return arbre[(indice+1)*2-1]

def fils_droit(arbre,noeud):
    if noeud in arbre:
        indice=arbre.index(noeud)
        return arbre[(indice+1)*2]

print("Fils gauche du noeud \"d\" dans arbre :",fils_gauche(arbre,"d"))
print("Fils droit du noeud \"d\" dans arbre :",fils_droit(arbre,"d"))

# 4)
def noeud_est_racine(arbre,noeud):
    if noeud in arbre:
        return noeud==arbre[0]

print("Noeud \"r\" est racine ? :",noeud_est_racine(arbre,"r"))
print("Noeud \"d\" est racine ? :",noeud_est_racine(arbre,"d"))

# 5)
def est_feuille(arbre,noeud):
    if noeud in arbre:
        return enfants_noeud(arbre,noeud)==(None,None)

print("Noeud \"m\" est feuille ? :",est_feuille(arbre,"m"))
print("Noeud \"e\" est feuille ? :",est_feuille(arbre,"e")) 

# 6)
def a_un_frere(arbre,noeud):
    if noeud in arbre:
        try:
            famille=enfants_noeud(arbre,parent(arbre,noeud))
            if famille==(None,None):
                raise AssertionError
            elif famille==(noeud,None) or famille==(None,noeud):
                return False
            else:
                return True
        except AssertionError:
            return False

print("Noeud \"f\" a un frère ? :",a_un_frere(arbre,"f"))
print("Noeud \"h\" a un frère ? :",a_un_frere(arbre,"h"))
print("Noeud \"r\" a un frère ? :",a_un_frere(arbre,"r"))