from Files_classe import File
from Exs_ArbresBinairesRecursifs_Jules_Rollier import arbre

def parcoursLargeur(arbre):
    f=File()
    liste=[]
    f.enfiler(arbre)
    while not f.vide():
        tmp=f.defiler()
        liste.append(tmp[0])
        if tmp[1]!=[]:
            f.enfiler(tmp[1])
        if tmp[2]!=[]:
            f.enfiler(tmp[2])
    return liste

if __name__=="__main__":
    print("Parcours en largeur de arbre :")
    print(parcoursLargeur(arbre))