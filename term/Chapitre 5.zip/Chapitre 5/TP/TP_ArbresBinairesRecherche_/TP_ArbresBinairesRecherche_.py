###-----A faire 1-----###
class Ville:
    def __init__(self,liste):
        self.__nom=liste[0]
        self.__departement=int(liste[1])
        self.__population=int(liste[2])
        self.__superficie=float(liste[3])
        self.__rang=int(liste[4])
    
    ###-----A faire 2-----###
    def getNom(self):
        return self.__nom
    
    def getDepartement(self):
        return self.__departement
    
    def getPopulation(self):
        return self.__population
    
    def getSuperficie(self):
        return self.__superficie
    
    def getRang(self):
        return self.__rang
    
    def getVille(self):
        return {"Nom":self.__nom,"Département":self.__departement,"Population":self.__population,"Superficie":self.__superficie,"Rang":self.__rang}


###-----A faire 1-----###
liste=["Nice","6","343123","71.9","5"]
ville=Ville(liste)


###-----A faire 2-----###
assert ville.getNom()=="Nice"
#assert ville.__nom,"L'attribut de ville est bien privé"


###-----A faire 3-----###
print(ville.getVille())


class Noeud:
    def __init__(self,liste,left=None,right=None):
        self.ville=Ville(liste)
        self.left=left
        self.right=right
    
    def __str__(self):
        return str(self.ville.getVille())
    
    def estFeuille(self):
        if not self.left and not self.right:
            return True
        else:
            return False
    
    ###-----A faire 4-----### 
    def inserer(self,liste):
        ville=Ville(liste)
        if ville.getRang()<self.ville.getRang():
            if self.left is None:
                self.left=Noeud(liste)
            else:
                self.left.inserer(liste)
        elif ville.getRang()>self.ville.getRang():
            if self.right is None:
                self.right=Noeud(liste)
            else:
                self.right.inserer(liste)
    
    def rechercher(self,rang):
        if self!=None:
            if self.ville.getRang()==rang:
                return self.ville.getVille()
            elif rang<self.ville.getRang() and self.left!=None:
                return self.left.rechercher(rang)
            elif rang>self.ville.getRang() and self.right!=None:
                return self.right.rechercher(rang)
            else:
                return "! Aucune ville n'est du rang renseigné !"
    
    def parcours_infixe_liste(self,liste_parcours):
        if self.left!=None:
            self.left.parcours_infixe_liste(liste_parcours)
        liste_parcours.append(self.ville.getVille())
        if self.right!=None:
            self.right.parcours_infixe_liste(liste_parcours)
        return liste_parcours
    
    def inserer_superficie(self,liste):
        ville=Ville(liste)
        if ville.getSuperficie()<self.ville.getSuperficie():
            if self.left is None:
                self.left=Noeud(liste)
            else:
                self.left.inserer_superficie(liste)
        elif ville.getSuperficie()>self.ville.getSuperficie():
            if self.right is None:
                self.right=Noeud(liste)
            else:
                self.right.inserer_superficie(liste)
    

###-----A faire 5-----###
import csv
liste_villes=[]
with open("villes.csv","r",encoding="utf-8") as f:
    lecteur=csv.reader(f,delimiter=",")
    for ligne in lecteur:
        liste_villes.append(ligne)

print(liste_villes)
print(len(liste_villes))

liste=["Maisons-Alfort","94","51091","5.4","100"]
noeud=Noeud(liste)
print(noeud)
for el in liste_villes:
    noeud.inserer(el)

###-----A faire 6-----###
# 1)
print(noeud.rechercher(87))

# 2)
print(noeud.parcours_infixe_liste([]))

# 3)
n=Noeud(liste_villes[0])
for i in range(1,len(liste_villes)):
    n.inserer_superficie(liste_villes[i])
print(n.parcours_infixe_liste([]))

# 4)
