###-----Exercice 1-----###
class ABR:
    def __init__(self,g0,v0,d0):
        self.gauche=g0
        self.cle=v0
        self.droit=d0
    
    def __repr__(self):
        if self is None:
            return ""
        else:
            return "("+(self.gauche).__repr__()+","+str(self.cle)+","+(self.droit).__repr__()+")"


n0=ABR(None,0,None)
n3=ABR(None,3,None)
n2=ABR(None,2,n3)
abr1=ABR(n0,1,n2)
print(abr1)

def ajoute(cle,a):
    if a!=None:
        if cle<a.cle:
            if a.gauche!=None: 
                ajoute(cle,a.gauche)
            else:
                a.gauche=ABR(None,cle,None)
        if cle>a.cle:
            if a.droit!=None: 
                ajoute(cle,a.droit)
            else:
                a.droit=ABR(None,cle,None)
    return a

ajoute(4,abr1)
print(abr1)


###-----Exercice 2-----###
class Noeud:
    '''classe implémentant un noeud d'arbre binaire'''
    def __init__(self, g, v, d):
        '''un objet Noeud possède 3 attributs :
        - gauche : le sous-arbre gauche,
        - valeur : la valeur de l'étiquette,
        - droit : le sous-arbre droit.
         '''
        self.gauche = g
        self.valeur = v
        self.droit = d

    def __str__(self):
        '''renvoie la représentation du noeud en chaine de caractères'''
        return str(self.valeur)

    def est_une_feuille(self):
        '''renvoie True si et seulement si le noeud est une feuille'''
        return self.gauche is None and self.droit is None
    
    def expression_infixe(e):
        s = ""
        if e.gauche is not None:
            s = '(' + s + expression_infixe(e.gauche)
            s = s + str(e.valeur)
        if e.droit is not None:
            s = s + expression_infixe(e.droit) + ")"
        return s
