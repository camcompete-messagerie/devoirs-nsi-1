from Exs_ClasseArbresBinaires_Jules_Rollier import Noeud

# 1)
# Au verso du sujet de TP

# 2)
quatre=Noeud(4,None,None)
sept=Noeud(7,None,None)
soustraction=Noeud("-",quatre,sept)
trois=Noeud(3,None,None)
division=Noeud("/",trois,soustraction)
deux=Noeud(2,None,None)
addition=Noeud("+",deux,division)

# 3)
def evalue(arbre):
    res=None
    if arbre.estFeuille(): # problème ici (manque le paramètre de la méthode estFeuille())
        res=arbre.value
    elif arbre.value=="+":
        res=evalue(arbre.left)+evalue(arbre.right)
    elif arbre.value=="-":
        res=evalue(arbre.left)-evalue(arbre.right)
    elif arbre.value=="*":
        res=evalue(arbre.left)*evalue(arbre.right)
    elif arbre.value=="/":
        res=evalue(arbre.left)/evalue(arbre.right)
    else:
        res=None
    return res

print(evalue(addition)==2+(3/(4-7)))

# 4)
multiplication2=Noeud("*",sept,trois)
six=Noeud(6,None,None)
addition2=Noeud("+",multiplication2,six)
neuf=Noeud(9,None,None)
division2=Noeud("/",addition2,neuf)

print(evalue(division2)==(7*3+6)/9)

# 