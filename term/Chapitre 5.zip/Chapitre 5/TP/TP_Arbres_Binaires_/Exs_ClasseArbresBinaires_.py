class Noeud: 
    def __init__(self, value, left=None, right=None): 
        self.value = value 
        self.left = left 
        self.right = right
    
    def estFeuille(self):
        return self.left==None and self.right==None
    
    def hauteur(self): 
        h1=0 
        h2=0 
        if not self: 
            return -1 
        else: 
            if self.left: 
                h1 = 1 + self.left.hauteur() 
            if self.right: 
                h2 = 1 + self.right.hauteur() 
            return max(h1, h2)
    
    def parcours_infixe(self): 
        if self.left!=None:
            self.left.parcours_infixe()
        print(self.value, end=' ')
        if self.right!=None:
            self.right.parcours_infixe()
 
    def parcours_prefixe(self): 
        print(self.value, end=' ')
        if self.left!=None:
            self.left.parcours_prefixe()
        if self.right!=None:
            self.right.parcours_prefixe()
     
    def parcours_suffixe(self): 
        if self.left!=None:
            self.left.parcours_suffixe()
        if self.right!=None:
            self.right.parcours_suffixe()
        print(self.value, end=' ')
    
    def taille(self):
        if self.left!=None:
            taille_gauche=self.left.taille()
        else:
            taille_gauche=0
        if self.right!=None:
            taille_droite=self.right.taille()
        else:
            taille_droite=0
        return taille_gauche+taille_droite+1
    
    def supprimer_branche(self,noeud):
        if self:
            if self.left==noeud:
                self.left=None
            elif self.right==noeud:
                self.right=None
            else:
                if self.left:
                    self.left.supprimer_branche(noeud)
                if self.right:
                    self.right.supprimer_branche(noeud)

    def __str__(self): 
        return str(self.value) 


if __name__=="__main__":
    k = Noeud('k') 
    f = Noeud('f') 
    e = Noeud('e', k, None) 
    b = Noeud('b', e, f) 
    m = Noeud('m') 
    j = Noeud('j', m, None) 
    i = Noeud('i') 
    d = Noeud('d', i, j) 
    h = Noeud('h') 
    c = Noeud('c', None, h) 
    a = Noeud('a', c, d) 
    arbre = Noeud('r', a, b) 
     
    print(arbre)

    print(arbre.estFeuille())
    print(arbre.estFeuille())

    def hauteur2(arbre) : 
        if not arbre: 
            return -1 
        else: 
            h1 = 1 + hauteur2(arbre.left) 
            h2 = 1 + hauteur2(arbre.right) 
            return max(h1,h2)

    print(hauteur2(arbre))

    print(arbre.hauteur())

    print(arbre.parcours_infixe())
    print(arbre.parcours_prefixe())
    print(arbre.parcours_suffixe())

    print(arbre.taille())
