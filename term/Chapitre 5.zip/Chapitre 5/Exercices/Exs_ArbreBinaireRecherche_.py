class Noeud:
    def __init__(self, value, left=None, right=None):
        self.value = value
        self.left = left
        self.right = right
        self.parent = None

    def __str__(self):
        return str(self.value)

    def estFeuille(self):
        if not self.left and not self.right:
            return True
        else:
            return False
    
    def insert(self,valeur):
        if valeur<self.value:
            if self.left is None:
                self.left=Noeud(valeur)
                self.left.parent=self
            else:
                self.left.insert(valeur)
        elif valeur>self.value:
            if self.right is None:
                self.right=Noeud(valeur)
                self.right.parent=self
            else:
                self.right.insert(valeur)
    
    def parcoursProfondeurPrefixe(self):
        print(self.value,end=" ; ")
        if self.left!=None:
            self.left.parcoursProfondeurPrefixe()
        if self.right!=None:
            self.right.parcoursProfondeurPrefixe()
    
    def parcoursProfondeurInfixe(self):
        if self.left!=None:
            self.left.parcoursProfondeurInfixe()
        print(self.value,end=" ; ")
        if self.right!=None:
            self.right.parcoursProfondeurInfixe()
    
    def parcoursProfondeurSuffixe(self):
        if self.left!=None:
            self.left.parcoursProfondeurSuffixe()
        if self.right!=None:
            self.right.parcoursProfondeurSuffixe()
        print(self.value,end=" ; ")
    
    def parcours_prefixe_liste(self,liste_parcours):
        liste_parcours.append(self.value)
        if self.left!=None:
            self.left.parcours_prefixe_liste(liste_parcours)
        if self.right!=None:
            self.right.parcours_prefixe_liste(liste_parcours)
        return liste_parcours
    
    def parcours_infixe_liste(self,liste_parcours):
        if self.left!=None:
            self.left.parcours_infixe_liste(liste_parcours)
        liste_parcours.append(self.value)
        if self.right!=None:
            self.right.parcours_infixe_liste(liste_parcours)
        return liste_parcours
    
    def parcours_suffixe_liste(self,liste_parcours):
        if self.left!=None:
            self.left.parcours_suffixe_liste(liste_parcours)
        if self.right!=None:
            self.right.parcours_suffixe_liste(liste_parcours)
        liste_parcours.append(self.value)
        return liste_parcours
    
    def minimum(self):
        if self.left==None:
            return self.value
        else:
            return self.left.minimum()
    
    def maximum(self):
        if self.right==None:
            return self.value
        else:
            return self.right.maximum()
    
    def recherche(self,valeur):
        if self.value==valeur:
            return True
        elif valeur<self.value:
            if self.left!=None:
                return self.left.recherche(valeur)
            return False
        elif valeur>self.value:
            if self.right!=None:
                return self.right.recherche(valeur)
            return False
    
    def chemin(self,valeur):
        if self!=None:
            if self.recherche(valeur):
                if valeur<self.value and self.left!=None:
                    return str(self.value) + "-->" + str(self.left.chemin(valeur))
                elif valeur>self.value and self.right!=None:
                    return str(self.value) + "-->" + str(self.right.chemin(valeur))
                elif valeur==self.value:
                    return str(self.value)
            else:
                return "! La valeur recherchée n'est pas dans l'ABR !"
    
    def supprimerNoeud(self,noeud):
        if self!=None:
            if self.recherche(noeud):
                if self.value==noeud:
                    if noeud<self.parent.value:
                        self.parent.left=None
                    elif noeud>self.parent.value:
                        self.parent.right=None
                elif noeud<self.value and self.left!=None:
                    return self.left.supprimerNoeud(noeud)
                elif noeud>self.value and self.right!=None:
                    return self.right.supprimerNoeud(noeud)
            else:
                print("! Le noeud renseigné est inexistant dans cet ABR !")


bst=Noeud(6)
bst.insert(8)
bst.insert(3)
bst.insert(1)
bst.insert(4)
bst.insert(9)
bst.insert(2)
bst.insert(7)
bst.insert(5)


if __name__=="__main__":
    ###-----Exercice 1-----###
    print("----------------------------Exercice 1----------------------------")
    print("Parcours préfixe :")
    bst.parcoursProfondeurPrefixe()
    print()
    print("Parcours infixe :")
    bst.parcoursProfondeurInfixe()
    print()
    print("Parcours suffixe :")
    bst.parcoursProfondeurSuffixe()


    ###-----Exercice 2-----###
    print()
    print()
    print("----------------------------Exercice 2----------------------------")
    print("Parcours préfixe :")
    print(bst.parcours_prefixe_liste([]))
    print("Parcours infixe :")
    print(bst.parcours_infixe_liste([]))
    print("Parcours suffixe :")
    print(bst.parcours_suffixe_liste([]))


    ###-----Exercice 3-----###
    print()
    print("----------------------------Exercice 3----------------------------")
    
    def liste_ABR(liste):
        arbre=Noeud(liste[0])
        for i in range(1,len(liste)):
            arbre.insert(liste[i])
        return arbre

    from random import randint,choice
    liste_test=[randint(0,20) for i in range(8)]
    print(f"Liste à convertir en ABR : {liste_test}")
    print(f"ABR implémenté à partir de la liste : {liste_ABR(liste_test).parcours_infixe_liste([])}")


    ###-----Exercice 4-----###
    print()
    print("----------------------------Exercice 4----------------------------")
    
    def tri_ABR_liste(liste):
        liste_vers_ABR=liste_ABR(liste)
        return liste_vers_ABR.parcours_infixe_liste([])

    liste_test_2=[randint(0,20) for i in range(8)]
    print(f"Liste à trier via un ABR : {liste_test_2}")
    print(f"Liste triée via un ABR : {tri_ABR_liste(liste_test_2)}")
   

    ###-----Exercice 5-----###7, 8, 9]
    print()
    print("----------------------------Exercice 5----------------------------")
    print(f"Minimum de l'ABR bst : {bst.minimum()}")
    
    
    ###-----Exercice 6-----###
    print()
    print("----------------------------Exercice 6----------------------------")
    print(f"Maximum de l'ABR bst : {bst.maximum()}")
    
    
    ###-----Exercice 7-----###
    print()
    print("----------------------------Exercice 7----------------------------")
    L_entiers=[randint(0,20) for i in range(8)]
    ABR_de_L_entiers=liste_ABR(L_entiers)
    print(f"L_entiers = {L_entiers}")
    entier1=choice([i for i in range(0,20)])
    print(f"Est ce que {entier1} est présent dans l'ABR implémenté depuis la liste L_entiers ? : {ABR_de_L_entiers.recherche(entier1)}")
    entier2=choice([i for i in range(0,20)])
    print(f"Est ce que {entier2} est présent dans l'ABR implémenté depuis la liste L_entiers ? : {ABR_de_L_entiers.recherche(entier2)}")
    
    print()
    
    L_animaux=["chat","chien","souris","araignée","crapaud","grenouille","lézard","zèbre"]
    ABR_de_L_animaux=liste_ABR(L_animaux)
    print(f"L_animaux = {L_animaux}")
    animal1="chien"
    print(f"Est ce que \"{animal1}\" est présent dans l'ABR implémenté depuis la liste L_animaux ? : {ABR_de_L_animaux.recherche(animal1)}")
    animal2="panda"
    print(f"Est ce que \"{animal2}\" est présent dans l'ABR implémenté depuis la liste L_animaux ? : {ABR_de_L_animaux.recherche(animal2)}")
    
    
    ###-----Exercice 8-----###
    print()
    print("----------------------------Exercice 8----------------------------")
    print(f"L_entiers = {L_entiers}")
    entier1=choice([i for i in range(0,20)])
    print(f"Chemin de {entier1} dans l'ABR implémenté depuis la liste L_entiers : {ABR_de_L_entiers.chemin(entier1)}")
    entier2=choice([i for i in range(0,20)])
    print(f"Chemin de {entier2} dans l'ABR implémenté depuis la liste L_entiers : {ABR_de_L_entiers.chemin(entier2)}")
    
    print()
    
    print(f"L_animaux = {L_animaux}")
    animal3="lézard"
    print(f"Chemin de \"{animal3}\" dans l'ABR implémenté depuis la liste L_animaux : {ABR_de_L_animaux.chemin(animal3)}")
    animal4="singe"
    print(f"Chemin de \"{animal4}\" dans l'ABR implémenté depuis la liste L_animaux : {ABR_de_L_animaux.chemin(animal4)}")
    
    
    ###-----Exercice 9-----###
    print()
    print("----------------------------Exercice 9----------------------------")
    print(f"ABR bst : {bst.parcours_infixe_liste([])}")
    entier_a_suppr=3
    bst.supprimerNoeud(entier_a_suppr)
    print(f"ABR bst auquel le noeud {entier_a_suppr} a été supprimé : {bst.parcours_infixe_liste([])}")
    
    print()
    
    print(f"ABR_de_L_animaux : {ABR_de_L_animaux.parcours_infixe_liste([])}")
    animal_a_suppr="crapaud"
    ABR_de_L_animaux.supprimerNoeud(animal_a_suppr)
    print(f"ABR bst auquel le noeud \"{animal_a_suppr}\" a été supprimé : {ABR_de_L_animaux.parcours_infixe_liste([])}")