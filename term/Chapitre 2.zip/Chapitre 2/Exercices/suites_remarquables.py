def nombre_Fibonacci(n):
    assert type(n)==int
    f0=0
    f1=1
    if n==0:
        return 0
    for i in range(2,n+1):
        f0,f1=f1,f0+f1
    return f1


def nombre_Catalan(n):
    assert type(n)==int
    if n<=1:
        return 1
    rep=0
    for i in range(n):
        rep=rep+(nombre_Catalan(i)*nombre_Catalan(n-i-1))
    return rep