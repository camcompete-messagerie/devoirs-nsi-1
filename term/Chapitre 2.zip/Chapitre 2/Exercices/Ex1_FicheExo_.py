from random import randint

# 1) Les deux condtitions sont que ma_liste soit de type list et que ma_liste ne soit pas vide.

# 2)
def minimum(ma_liste):
    assert type(ma_liste)==list, "Le paramètre que vous avez renseigné n'est pas une liste."
    assert len(ma_liste)>0, "La liste renseignée est vide."
    longueur=len(ma_liste)   # Initialisation de la variable longueur par la longueur de  ma_liste
    mini=ma_liste[0]   # Initialisation de la variable mini par la première valeur de ma_liste
    i=1   # Initialisation de la variable i à 1
    while i<longueur:   # Tant que i est inférieur à la longueur de ma_liste
        if ma_liste[i]<mini:   # Si l'élément à l'indice i dans ma_liste est inférieur à la valeur minimale de ma_liste
            mini=ma_liste[i]   # La variable mini prend la valeur de l'élément à l'indice i dans ma_liste
        i=i+1   # La variable i est incrémentée de 1
    return mini   # Retour de la plus petite valeur de ma_liste

L=[randint(0,100) for i in range(10)]
print(L)
print(f"Le minimum de la liste est {minimum(L)}.")