from suites_remarquables import nombre_Fibonacci,nombre_Catalan

assert type(nombre_Fibonacci(3))==int
assert nombre_Fibonacci(0)==0
assert nombre_Fibonacci(1)==1
assert nombre_Fibonacci(2)==1
assert nombre_Fibonacci(3)==2
assert nombre_Fibonacci(4)==3
assert nombre_Fibonacci(5)==5
assert nombre_Fibonacci(6)==8

assert type(nombre_Catalan(3))==int
assert nombre_Catalan(0)==1
assert nombre_Catalan(1)==1
assert nombre_Catalan(2)==2
assert nombre_Catalan(3)==5
assert nombre_Catalan(4)==14
assert nombre_Catalan(5)==42
assert nombre_Catalan(6)==132