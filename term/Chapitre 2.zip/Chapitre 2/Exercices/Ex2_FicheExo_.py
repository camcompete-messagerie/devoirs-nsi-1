from suites_remarquables import nombre_Fibonacci,nombre_Catalan

def ask_user():
    try:
        n=int(input("Entrez un entier naturel non nul : "))
        assert n>=1
        print(f"Le {n}ème nombre de la suite de Fibonacci est {nombre_Fibonacci(n)}.")
        print(f"Le {n}ème nombre de la suite de des nombres de Catalan est {nombre_Catalan(n)}.")
    except AssertionError:
        print("Le nombre entier saisi doit être supérieur ou égal à 1.")
        ask_user()
    except:
        print("Vous devez saisir un nombre entier naturel.")
        ask_user()

ask_user()