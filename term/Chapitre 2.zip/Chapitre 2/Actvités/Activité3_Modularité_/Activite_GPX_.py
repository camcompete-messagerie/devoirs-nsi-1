import folium
from lecture_GPX import liste_points
from math import sin,cos,acos,pi


def vitesse_entre_2_points(pointA,pointB):
    """
    Renvoie la distance entre le point A et le point B en kilomètres/heure.
    """
    latA=pointA[0]/180*pi
    longA=pointA[1]/180*pi
    latB=pointB[0]/180*pi
    longB=pointB[1]/180*pi
    
    RT=6378137
    S=acos(sin(latA)*sin(latB) + cos(latA)*cos(latB)*cos(abs(longB-longA)))
    return (S*RT)*3.6


fmap=folium.Map(location=[45.74732851596591,4.710339225100168], tiles="OpenStreetMap", zoom_start=14)

folium.Marker(liste_points[0],
                    popup="Domicile de Madame Vernier",
                    icon=folium.Icon(color="blue")).add_to(fmap)
folium.Marker(liste_points[-1],
                    popup="Institution Saint-Joseph <img src='image_STJO.jpg' width='150px'/>",
                    icon=folium.Icon(color="red")).add_to(fmap)

for i in range(len(liste_points)-1):
    if vitesse_entre_2_points(liste_points[i],liste_points[i+1])<=30:
        folium.PolyLine([liste_points[i],liste_points[i+1]],color='green',weight=3,opacity=0.6).add_to(fmap)
    elif 30<vitesse_entre_2_points(liste_points[i],liste_points[i+1])<=50:
        folium.PolyLine([liste_points[i],liste_points[i+1]],color='orange',weight=3,opacity=0.6).add_to(fmap)
    elif 50<vitesse_entre_2_points(liste_points[i],liste_points[i+1])<=70:
        folium.PolyLine([liste_points[i],liste_points[i+1]],color='red',weight=3,opacity=0.6).add_to(fmap)
    elif 70<vitesse_entre_2_points(liste_points[i],liste_points[i+1]):
        folium.PolyLine([liste_points[i],liste_points[i+1]],color='purple',weight=3,opacity=0.6).add_to(fmap)

fmap.save("Carte_Trace_GPX.html")