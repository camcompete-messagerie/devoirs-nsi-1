from lxml import etree
inputFilename="28-Sep-2021-0859.gpx"
root=etree.parse(inputFilename)
ns="http://www.topografix.com/GPX/1/1"
liste_points_nuls=root.xpath("/ns:gpx/ns:trk/ns:trkseg/ns:trkpt",namespaces={"ns":ns})
latitude=[]
longitude=[]
temps=[]
for point in liste_points_nuls:
    latitude.append(float(point.get("lat")))
    longitude.append(float(point.get("lon")))
    for enfant in point.getchildren():
        if enfant.tag=="{"+ns+"}time":
            temps.append(enfant.text)

liste_points=[(latitude[i],longitude[i]) for i in range(len(latitude))]