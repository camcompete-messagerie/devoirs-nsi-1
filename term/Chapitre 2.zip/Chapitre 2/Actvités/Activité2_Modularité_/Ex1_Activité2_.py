import csv,folium

with open("communes-departement-region.csv","r",encoding="utf-8",newline="") as fichier:
    table=list(csv.DictReader(fichier,delimiter=","))

demande_ville=input("Entrez le nom d'une ville (avec l'orthographe exacte) : ")

communes69=[]
for commune in table:
    if commune["code_departement"]=="69":
        communes69.append(commune)

for commune in communes69:
    if demande_ville==commune["nom_commune_complet"]:
        coordo_ville=[commune["latitude"],commune["longitude"]]
        nom_ville=commune["nom_commune_complet"]

        fmap=folium.Map(location=coordo_ville, tiles="OpenStreetMap", zoom_start=10)

        folium.Marker(coordo_ville,
                        popup=nom_ville,
                        icon=folium.Icon(color="blue")).add_to(fmap)

        file="departement-69-rhone.geojson"
        folium.GeoJson(file,name="Rhône").add_to(fmap)

        fmap.save("Carte_69_Ex1.html")