import csv,folium
from math import sin, cos, acos, pi

with open("communes-departement-region.csv","r",encoding="utf-8",newline="") as fichier:
    table=list(csv.DictReader(fichier,delimiter=","))

demande_ville1=input("Entrez le nom de la première ville (avec l'orthographe exacte) : ")
demande_ville2=input("Entrez le nom de la seconde ville (avec l'orthographe exacte) : ")

for commune in table:
    if demande_ville1==commune["nom_commune_complet"]:
        ville1={"nom":commune["nom_commune_complet"], "coordonnées":[float(commune["latitude"]),float(commune["longitude"])]}
    if demande_ville2==commune["nom_commune_complet"]:
        ville2={"nom":commune["nom_commune_complet"], "coordonnées":[float(commune["latitude"]),float(commune["longitude"])]}
        
def creer_carte(ville1,ville2):
    fmap=folium.Map(location=[46.795460938951116,2.842541161307355], tiles="OpenStreetMap", zoom_start=6)
    
    folium.Marker(ville1["coordonnées"],
                    popup=ville1["nom"],
                    icon=folium.Icon(color="blue")).add_to(fmap)
    folium.Marker(ville2["coordonnées"],
                    popup=ville2["nom"],
                    icon=folium.Icon(color="red")).add_to(fmap)
    
    points=[tuple(ville1["coordonnées"]),tuple(ville2["coordonnées"])]
    folium.PolyLine(points,color='purple',weight=3,opacity=0.6).add_to(fmap)

    fmap.save("Carte_Distance_Ex2.html")

creer_carte(ville1,ville2)

def deg2rad(dd):
    """Convertit un angle "degrés décimaux" en "radians"
    """
    return dd/180*pi

def distanceGPS(latA, longA, latB, longB):
    """Retourne la distance en mètres entre les 2 points A et B connus grâce à
       leurs coordonnées GPS (en radians).
    """
    RT=6378137
    S=acos(sin(latA)*sin(latB) + cos(latA)*cos(latB)*cos(abs(longB-longA)))
    return S*RT


latA = deg2rad(ville1["coordonnées"][0])
longA = deg2rad(ville1["coordonnées"][1])

latB = deg2rad(ville2["coordonnées"][0])
longB = deg2rad(ville2["coordonnées"][1])

dist = distanceGPS(latA, longA, latB, longB)/1000
print(f"La distance entre {demande_ville1} et {demande_ville2} est : {int(dist)}km.")