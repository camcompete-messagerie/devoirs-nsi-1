######################
###---Activité 1---###
######################

# 1)

# 2)
"""
try:
    Bloc principal
except:
    Bloc en cas d'erreur dans le bloc principal
"""

# 3)
"""
try:
    Bloc principal
except XXXXXnom-de-l'erreur:
    Bloc en cas d'erreur XXXXXnom-de-l'erreur dans le bloc principal
"""

# 4) Les effets de bord


######################
###---Activité 2---###
######################

# 1)
def saisie_entier():
    try:
        return int(input("Veuillez saisir un entier : "))
    except ValueError:
        print("Ce que vous avez saisi n'est pas un nombre.")
        return saisie_entier()
        
saisie_entier()

# 2)
def saisie_entier_controle(debut,fin):
    try:
        q=int(input("Veuillez saisir un entier : "))
        #if q>debut:
            
    except ValueError:
        print("Ce que vous avez saisi n'est pas un nombre.")
        return saisie_entier()