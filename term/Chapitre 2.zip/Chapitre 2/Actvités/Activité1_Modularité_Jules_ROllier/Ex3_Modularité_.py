import folium

fmap=folium.Map(location=[45.759687644819515,4.768322674285022],tiles="OpenStreetMap",zoom_start=16)

folium.Marker([45.76025473087431,4.758537520277535],popup="Lycée Saint-Joseph, le meilleur des lycées",icon=folium.Icon(color="green")).add_to(fmap)
folium.Marker([45.76158643401057,4.758586478870236],popup="Gare de Tassin",icon=folium.Icon(color="orange")).add_to(fmap)
folium.Marker([45.75700423155284,4.768815898689131],popup="Stade René Dubot",icon=folium.Icon(color="blue")).add_to(fmap)
folium.Marker([45.76133126054066,4.777346887025174],popup="Hôtel de ville de Tassin",icon=folium.Icon(color="purple")).add_to(fmap)

fmap.save("Carte_Tassin_Ex3.html")