import folium

fmap=folium.Map(location=[45.76025473087431,4.758537520277535],tiles="OpenStreetMap",zoom_start=16)

folium.Marker([45.76025473087431,4.758537520277535],popup="Lycée Saint-Joseph, le meilleur des lycées",icon=folium.Icon(color="green")).add_to(fmap)

fmap.save("Carte_STJO_Ex2.html")