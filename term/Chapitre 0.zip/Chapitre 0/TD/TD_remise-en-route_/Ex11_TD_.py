from random import randint

l=[randint(0,100) for i in range(10)]
                
def tri_a_bulles(L):
    """
    Tri la liste L sur place par un tri à bulles"
    Input : L --> liste d'entiers - list.
    Output : L --> liste d'entiers triée sur place - list.
    """
    assert type(L)==list, "Le paramètre n'est pas une liste."
    n = len(L)
    for i in range(n):
        for j in range(0, n-i-1):
            if L[j] > L[j+1] :
                L[j], L[j+1] = L[j+1], L[j]
    return L

assert tri_a_bulles(l)==sorted(l), "La liste n'est pas triée."

print(tri_a_bulles(l))