from Ex1_TD_Jules_Rollier import nb_aleatoire

def mini(L):
    """
    Renvoie le nombre le plus petit de la liste.
    Input : L --> liste d'entiers - list.
    Output : mini --> nombre minimum de la liste L - int.
    """
    assert type(L)==list, "Le paramètre n'est pas une liste."
    mini=L[0]
    for nb in L:
        if nb<mini:
            mini=nb
    return mini

L=nb_aleatoire()

assert mini(L)==min(L), "Résultat incorrect."

if __name__=="__main__":
    print(sorted(L))
    print(mini(L))