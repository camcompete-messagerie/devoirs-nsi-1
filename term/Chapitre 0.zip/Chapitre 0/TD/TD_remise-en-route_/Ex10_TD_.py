from Ex1_TD_Jules_Rollier import nb_aleatoire

l_test=nb_aleatoire()

def tri_insertion(L):
    """
    Tri la liste L en faisant un tri par insertion.
    Input : L --> liste aléatoire d'entiers - list.
    Output : L --> liste d'entiers triée sur place - list.
    """
    n=len(L)
    for k in range(1,n):
        j=k
        while j>0 and L[j-1]>L[j]:
            L[j],L[j-1]=L[j-1],L[j]
            j-=1
    return L

assert tri_insertion(l_test)==sorted(l_test), "La liste n'est pas triée."

print(tri_insertion(l_test))