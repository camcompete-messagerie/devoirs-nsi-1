mot_test="bonjour"

def inverse(mot):
    """
    Renvoie le mot en paramètre à l'envers.
    Input : mot --> mot à mettre à l'envers - str.
    Output : tom --> mot à l'envers - str.
    """
    assert type(mot)==str, "Le paramètre n'est pas un str."
    tom=""
    for i in range(len(mot)-1,-1,-1):
        tom+=mot[i]
    return tom

assert inverse(mot_test)==mot_test[::-1], "Le mot inversé est incorrect."

if __name__=="__main__":
    print(inverse(mot_test))