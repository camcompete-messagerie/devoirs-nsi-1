from random import randint

A=randint(1,1000)
B=randint(1,1000)

def PGCDsoustraction(a,b):
    """
    Calcule le PGCD par soustraction des nombres a et b.
    Input : a, b --> nombres à calculer - int.
    Output : a --> PGCD de a et b - int.
    """
    assert type(a) and type(b)==int, "a et b ne sont pas des nombres entiers."
    if b>a:
        a,b=b,a
    c=1
    while c!=0:
        c=a-b
        if c<=b:
            a=b
            b=c
        elif c>b:
            a=c
    return a

def PGCDdivision(a,b):
    """
    Calcule le PGCD par division des nombres a et b.
    Input : a, b --> nombres à calculer - int.
    Output : a --> PGCD de a et b - int.
    """
    assert type(a) and type(b)==int, "a et b ne sont pas des nombres entiers."
    while a!= 0 :
        if a>b:
            a=a%b
        elif b>a:
            a,b=b%a,a
    return b

print(f"Le PGCD par soustraction de {A} et {B} est {PGCDsoustraction(A,B)}")
print(f"Le PGCD par division de {A} et {B} est {PGCDdivision(A,B)}")