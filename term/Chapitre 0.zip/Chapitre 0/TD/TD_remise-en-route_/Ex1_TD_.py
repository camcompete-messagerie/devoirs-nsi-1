from random import randint

def nb_aleatoire():
    return [randint(0,100) for i in range(20)]

def somme(L):
    """
    Calcule la somme des termes de la liste.
    Input : L --> liste d'entiers - list.
    Output : s --> somme des entiers de la liste L - int.
    """
    assert type(L)==list, "Le paramètre n'est pas une liste."
    s=0
    for entier in L:
        s+=entier
    return s

L=nb_aleatoire()

assert somme(L)==sum(L), "Somme incorrecte."

if __name__=="__main__":
    print(L)
    print(somme(L))