from random import randint

def deconvers(mot,b):
    """
    Input : mot --> nombre en base b - str.
            b --> base du nombre mot - int.
    Output : nb --> mot en base b converti en base 10 - int.
    """
    assert type(mot)==str, "Mot n'est pas un str."
    assert type(b)==int, "b n'est pas un int."
    signes="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    nb=0
    i=0
    for lettre in mot:
        nb+=signes.index(lettre)*(b**(len(mot)-1-i))
        i+=1        
    return nb

print(deconvers("FA3",16))