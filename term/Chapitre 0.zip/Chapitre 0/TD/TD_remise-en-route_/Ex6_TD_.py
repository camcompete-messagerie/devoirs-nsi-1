# Cette fonction converti en base b un nombre n écrit en base 10.

def conversion(n,b):
    """
    Renvoie le nombre n en base b.
    Input : n --> nombre à convertir en base b - int.
            b --> base désirée pour le nombre n - int.
    Output : mot --> nombre n converti en base b - str.
    """
    assert type(n)==int, "Le paramètre n n'est pas un entier."
    assert type(b)==int, "Le paramètre b n'est pas un entier."
    signes="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    mot=""
    while n!=0:
        mot=signes[n%b]+mot
        n=n//b
    return mot

nombre=57
base=2

if __name__=="__main__":
    print(conversion(nombre,base))

