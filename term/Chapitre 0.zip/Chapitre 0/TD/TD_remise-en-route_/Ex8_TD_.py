def fibonacci(n):
    """
    Calcul les n premiers termes de la suite de Fibonacci.
    Input : n --> nombre de termes à calculer - int.
    Output : l_fibo --> n premiers termes de la suite de Fibonacci - list.
    """
    assert type(n)==int, "Le nombre de termes à calculer n'est pas entier."
    F0=0
    F1=1
    l_fibo=[F0,F1]
    for i in range(n-2):
        F2=F0+F1
        F0=F1
        F1=F2
        l_fibo.append(F2)
    return l_fibo

assert fibonacci(5)==[0, 1, 1, 2, 3]

print(fibonacci(10))