from Ex1_TD_Jules_Rollier import nb_aleatoire

def maxi(L):
    """
    Renvoie le nombre le plus grand de la liste.
    Input : L --> liste d'entiers - list.
    Output : maxi --> nombre maximum de la liste L - int.
    """
    assert type(L)==list, "Le paramètre n'est pas une liste."
    maxi=L[0]
    for nb in L:
        if nb>maxi:
            maxi=nb
    return maxi

L=nb_aleatoire()

assert maxi(L)==max(L), "Résultat incorrect."

if __name__=="__main__":
    print(sorted(L))
    print(maxi(L))