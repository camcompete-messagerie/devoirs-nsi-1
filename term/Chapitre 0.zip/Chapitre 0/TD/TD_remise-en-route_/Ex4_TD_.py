from random import randint

def puissance(x,n):
    """
    Renvoie le nombre x à la puissance n.
    Input : x --> nombre sur lequel appliquer la puissance - int.
            n --> puissance à appliquer sur le nombre - int.
    Output : res --> résultat de la puissance n sur le nombre x - int.
    """
    assert type(n)==int, "Le paramètre de puissance n'est pas entier."
    res=1
    for i in range(n):
        res=res*x
    return res

X=randint(0,10)
N=randint(0,3)

assert puissance(X,N)==X**N, "Resultat incorrect."

if __name__=="__main__":
    print(f"{X}^{N} = {puissance(X,N)}")