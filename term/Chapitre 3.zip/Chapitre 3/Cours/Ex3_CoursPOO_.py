# 1) self.paquetCarte est de type list.

# 2) La classe carte est instanciée dans la méthode creerPaquet().

# 3)
"""
if nbCartes in (32,52):
    self.nombreCartes=nbCartes
else:
    self.nombreCartes=52
    print("Le jeu de cartes peut contenir 32 ou 52 cartes. Le jeu de cartes a été initialisé à 52 cartes par défaut")
"""

# 4) Il est important de faire cette vérification car sinon le jeu de cartes n'auraient aucun sens (pas le même nombre de chaque carte).

# 5) Si la valeur n'est pas correcte, il faudrait afficher un message disant qu'un jeu de 52 cartes a été créé par défaut.

# 6) La méthode creerPaquet() n'a pas besoin d'autre paramètre autre que self car le paquet créé sera de la taille de l'attribut nombreCartes.

# 7) La méthode creerPaquet() sera utilisée dans le constructeur.

# 8) Il manque : from Carte import *

# 9)
"""
j1=JeuDeCartes(52)
j1.melanger()
j1.distribuerUneCarte()
"""


class JeuDeCartes:
    def __init__(self,nbCartes):
        if nbCartes in (32,52):
            self.nombreCartes=nbCartes
        else:
            print("Le jeu de cartes peut contenir 32 ou 52 cartes.")

j1=JeuDeCartes(36)