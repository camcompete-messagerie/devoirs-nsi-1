class Carte:
    def __init__(self,nom,couleur): #constructeur
        if nom in ('2','3','4','5','6','7','8','9','10','Valet','Dame','Roi','As'):
            self.nom=nom
            dico_valeurs={'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'10':10,'Valet':11,'Dame':12,'Roi':13,'As':14}
            self.valeur=dico_valeurs[nom]
        else:
            print("! Le nom de votre carte doit être un str (1 à 10 et Valet à As) !")
        if couleur in ('CARREAU','COEUR','TREFLE','PIQUE'):
            self.couleur=couleur
        else:
            print("! La couleur de votre carte doit être un str (CARREAU, COEUR, TREFLE ou PIQUE) !")
    
    def getNom(self): #getter
        return self.nom
    
    def getValeur(self): #getter
        return self.valeur
    
    def getCouleur(self): #getter
        return self.couleur
    
    def setNom(self,nom): #setter
        if nom in ('2','3','4','5','6','7','8','9','10','Valet','Dame','Roi','As'):
            self.nom=nom
            dico_valeurs={'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'10':10,'Valet':11,'Dame':12,'Roi':13,'As':14}
            self.valeur=dico_valeurs[nom]
        else:
            print("! Le nom de votre carte doit être un str (1 à 10 et Valet à As) !")
    
    def setCouleur(self,couleur): #setter
        if couleur in ('CARREAU','COEUR','TREFLE','PIQUE'):
            self.couleur=couleur
        else:
            print("! La couleur de votre carte doit être un str (CARREAU, COEUR, TREFLE ou PIQUE) !")
    
    def egalite(self,carte): #autre
        return self.valeur==carte.getValeur()
        
    def estSuperieureA(self,carte): #autre
        return self.valeur>carte.getValeur()
        
    def estInferieureA(self,carte): #autre
        return self.valeur<carte.getValeur()



########### Test de la classe Carte ###########
if __name__=='__main__':
    valetCoeur = Carte('Valet', 'COEUR')
    print('Nom:', valetCoeur.getNom())
    print('Couleur:', valetCoeur.getCouleur())
    print('Valeur:', valetCoeur.getValeur())
    valetCoeur.setNom('Dame')
    print('Nom modifié:', valetCoeur.getNom())
    print('Valeur modifiée:', valetCoeur.getValeur())
    asPique=Carte('As', 'PIQUE')
    print('As de Pique égale à Dame de Coeur ?',
    asPique.egalite(valetCoeur))
    print('As de Pique supérieur à Dame de Coeur ?',
    asPique.estSuperieureA(valetCoeur))
    print('As de Pique inférieur à Dame de Coeur ?',
    asPique.estInferieureA(valetCoeur))
    # Essai des exceptions: cette instruction conduit à une erreur
    dameCarreau = Carte('Dame', 'COooEUR')