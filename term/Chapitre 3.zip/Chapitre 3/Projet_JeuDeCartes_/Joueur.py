class Joueur:
    def __init__(self,nom,nbCartes=0):
        try:
            assert type(nom)==str
            self.nomJoueur=nom
            assert type(nbCartes)==int and 0<=nbCartes<=52
            self.nbCartes=nbCartes
            self.mainJoueur=[]
        except:
            print("! Le nom du joueur ou le nombre de carte n'est pas valide (nom en str et nombre de carte en int) !")
        
    def getNom(self): #getter
        return self.nomJoueur
    
    def getNbCartes(self): #getter
        return self.nbCartes
    
    def getMain(self): #getter
        
        L=[]
        for carte in self.mainJoueur:
            L.append((carte.getNom(),carte.getCouleur()))
        return L
        """
        return self.mainJoueur
        """
    
    def setMain(self,main): #setter
        self.mainJoueur=main
        self.nbCartes=len(main)
    
    def jouerCarte(self): #autre
        if self.nbCartes<1:
            return None
        else:
            carte=self.mainJoueur.pop()
            self.nbCartes-=1
            return carte
    
    def insererMain(self,liste): #autre
        self.mainJoueur=liste+self.mainJoueur
