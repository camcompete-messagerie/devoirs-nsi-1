from Carte import *
from random import shuffle

class JeuDeCartes:
    def __init__(self,nbCartes): #constructeur
        try:
            assert nbCartes in (32,52)
            self.nbCartes=nbCartes
            self.listeCartes=[]
        except:
            self.nbCartes=52
            self.listeCartes=[]
            print("! Le nombre de cartes saisi est invalide. Par défaut le jeu de cartes créé comporte 52 cartes !")
    
    def getNbCartes(self): #getter
        return self.nbCartes
    
    def getListeCartes(self): #getter
        """
        L=[]
        for carte in self.listeCartes:
            L.append((carte.getNom(),carte.getCouleur()))
        return L
        """
        return self.listeCartes
        
    def creerJeu(self): #autre
        noms_cartes=('2','3','4','5','6','7','8','9','10','Valet','Dame','Roi','As')
        couleurs_cartes=('CARREAU','COEUR','TREFLE','PIQUE')
        for couleur in couleurs_cartes:
            for nom in range(-1,-int(self.nbCartes/4)-1,-1):
                self.listeCartes.append(Carte(noms_cartes[nom],couleur))
    
    def melanger(self): #autre
        shuffle(self.listeCartes)
    
    def distribuerCarte(self): #autre
        carte=self.listeCartes.pop(0)
        self.nbCartes-=1
        return carte
    
    def distribuerJeu(self,nbJoueurs,nbCartes): #autre
        try:
            assert nbJoueurs*nbCartes<=self.nbCartes
            mains=[[] for a in range(nbJoueurs)]
            for i in range(nbCartes):
                for j in range(nbJoueurs):
                    carte=self.listeCartes.pop()
                    self.nbCartes-=1
                    mains[j].append(carte)
            return mains
        except AssertionError:
            print("! Il n'y a pas assez de cartes pour tous les joueurs !")



####### Test de la classe JeuDeCartes #######
if __name__=='__main__':
    jeu52 = JeuDeCartes(37)
    print("Taille du jeu =",jeu52.getNbCartes())
    jeu52.creerJeu()
    jeu52.melanger()
    L=jeu52.getListeCartes()
    carte= L[2] # la 3e carte
    print('Nom:', carte.getNom())
    print('Couleur:', carte.getCouleur())
    print('Valeur:', carte.getValeur())
    print("Taille du jeu =",jeu52.getNbCartes())
    # Distribution de 4 cartes à 3 joueurs
    distribution_3j_4c = jeu52.distribuerJeu(3,4)
    for i in range(3):
        print('Joueur', i+1, ':')
        listeCartes = distribution_3j_4c[i]
        for c in listeCartes:
            print(c.getNom(), 'de', c.getCouleur())
    print("Taille du jeu =",jeu52.getNbCartes())
    # Distribution de 10 cartes à 6 joueurs pour générer une exception (6 × 10 > 52)
    distribution_6j_10c = jeu52.distribuerJeu(6,10)
    print("Taille du jeu =",jeu52.getNbCartes())