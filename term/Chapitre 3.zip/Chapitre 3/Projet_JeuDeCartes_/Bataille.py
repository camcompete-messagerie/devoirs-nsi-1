from Carte import *
from JeuDeCartes import *
from Joueur import *

class Bataille:
    def __init__(self,nbCartes,nomJ1,nomJ2):
        self.jeu=JeuDeCartes(nbCartes)
        self.jeu.creerJeu()
        self.jeu.melanger()
        #print(self.jeu.getListeCartes())
        self.joueur1=Joueur(nomJ1,int(nbCartes/2))
        self.joueur2=Joueur(nomJ2,int(nbCartes/2))
        jeu_distribue=self.jeu.distribuerJeu(2,int(nbCartes/2))
        #print(jeu_distribue)
        self.joueur1.setMain(jeu_distribue[0])
        self.joueur2.setMain(jeu_distribue[1])
        print(self.joueur1.getMain())
        print(self.joueur2.getMain())
        
    
    def jouer(self):        
        while self.joueur1.getNbCartes()>0 or self.joueur2.getNbCartes()>0:
            carteJ1=self.joueur1.jouerCarte()
            carteJ2=self.joueur2.jouerCarte()
            if carteJ1==None or carteJ2==None:
                break
            
            if carteJ1.egalite(carteJ2):
                self.joueur1.insererMain([carteJ1])
                self.joueur2.insererMain([carteJ2])
                self.joueur1.nbCartes+=1
                self.joueur2.nbCartes+=1
                print("égalité")
                print(carteJ1.getNom(),"de",carteJ1.getCouleur())
                print(carteJ2.getNom(),"de",carteJ2.getCouleur())
                print()
                
            elif carteJ1.estSuperieureA(carteJ2):
                self.joueur1.insererMain([carteJ2,carteJ1])
                self.joueur1.nbCartes+=2
                print("carteJ1 > carteJ2")
                print(carteJ1.getNom(),"de",carteJ1.getCouleur())
                print(carteJ2.getNom(),"de",carteJ2.getCouleur())
                print()
                
            elif carteJ2.estSuperieureA(carteJ1):
                self.joueur2.insererMain([carteJ1,carteJ2])
                self.joueur2.nbCartes+=2
                print("carteJ1 < carteJ2")
                print(carteJ1.getNom(),"de",carteJ1.getCouleur())
                print(carteJ2.getNom(),"de",carteJ2.getCouleur())
                print()
            
            else:
                print("! Problème, les cartes ne se comparent pas !")
        
        if self.joueur1.getNbCartes()<=0:
            print(f"Le joueur {self.joueur2.getNom()} a gagné !")
        elif self.joueur2.getNbCartes()<=0:
            print(f"Le joueur {self.joueur1.getNom()} a gagné !")
        else:
            print("! Problème, aucun gagnant !")          



bataille=Bataille(32,"SamSam","Homer")
print(bataille.joueur2.getNbCartes())
bataille.jouer()