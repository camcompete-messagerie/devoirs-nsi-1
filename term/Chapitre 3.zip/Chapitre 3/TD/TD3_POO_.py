class Piece:
    def __init__(self,nom,surface):
        if type(nom)==str:
            self.nom=nom
        else:
            print("Le nom de votre pièce doit être un str.")
        if type(surface) in (float,int):
            self.surface=surface
        else:
            print("La surface de votre pièce doit être un float.")
            
    def getNom(self):
        return self.nom
    
    def getSurface(self):
        return self.surface
    
    def setNom(self,nouveau_nom):
        if type(nouveau_nom)==str:
            self.nom=nouveau_nom
        else:
            print("Le nom de votre pièce doit être un str.")
            
    def setSurface(self,nouvelle_surface):
        if type(nouvelle_surface) in (float,int):
            self.surface=nouvelle_surface
        else:
            print("La surface de votre pièce doit être un float.")



class Appartement:
    def __init__(self,nom):
        if type(nom)==str:
            self.nom=nom
        else:
            print("Le nom de votre pièce doit être un str.")
        self.listePieces=[]
    
    def getNom(self):
        return self.nom
    
    def getListePieces(self):
        liste_piece_surface=[]
        for piece in self.listePieces:
            liste_piece_surface.append((piece.getNom(),piece.getSurface()))
        return liste_piece_surface
    
    def setNom(self,nouveau_nom):
        if type(nouveau_nom)==str:
            self.nom=nouveau_nom
        else:
            print("Le nom de votre pièce doit être un str.")
    
    def ajouter(self,nouvelle_piece):
        self.listePieces.append(nouvelle_piece)
    
    def nbPieces(self):
        return len(self.listePieces)
    
    def surfaceTotale(self):
        surface_totale=0
        for piece in self.listePieces:
            surface_totale+=piece.getSurface()
        return round(surface_totale,1)


   
a=Appartement('appt25')
p1=Piece("chambre", 11.1)
p2=Piece("sdbToilettes", 7)
p3=Piece("cuisine", 7)
p4=Piece("salon", 21.3)
print(p4.getNom(),p4.getSurface())
p1.setSurface(12.6)
a.ajouter(p1)
a.ajouter(p2)
a.ajouter(p3)
a.ajouter(p4)
print(a.getNom(),a.getListePieces())
print('nb pieces =', a.nbPieces(),', Surface totale =',a.surfaceTotale())