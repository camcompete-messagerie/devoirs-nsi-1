class Carte:
    def __init__(self,nom,couleur):
        if nom in ('2','3','4','5','6','7','8','9','10','Valet','Dame','Roi','As'):
            self.nom=nom
        else:
            print("ça marche pas")
        dico_valeurs={'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'10':10,'Valet':11,'Dame':12,'Roi':13,'As':14}
        if nom in dico_valeurs.keys():
            self.valeur=dico_valeurs[nom]
        else:
            print("ça marche pas")
        if couleur in ('CARREAU','COEUR','TREFLE','PIQUE'):
            self.couleur=couleur
        else:
            print("ça marche pas")
    
    def getNom(self):
        return self.nom
    
    def getValeur(self):
        return self.valeur
    
    def getCouleur(self):
        return self.couleur
    
    def setNom(self, nom):
        self.nom=nom
        
    def setValeur(self, valeur):
        self.valeur=valeur
    
    def setCouleur(self, couleur):
        self.couleur=couleur
    
    def egalite(self, carte):
        ''' Renvoie True si les cartes self et carte ont même valeur, False sinon carte: Objet de type Carte '''
        return self.valeur==carte.getValeur()
        
    def estSuperieureA(self, carte):
        ''' Renvoie True si la valeur de self est supérieure à celle de carte, False sinon carte: Objet de type Carte'''
        return self.valeur>carte.getValeur()
        
    def estInferieureA(self, carte):
        ''' Renvoie True si la valeur de self est inférieure à celle de carte, False sinon c'''
        return self.valeur<carte.getValeur()