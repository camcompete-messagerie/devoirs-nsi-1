class Carte:
    def __init__(self,c,v):
        try:
            assert v in [i for i in range(1,14)]
            self.Valeur=v
        except:
            print("Vous devez renseigner une valeur de carte valide !")
        try:
            assert c in (0,1,2,3)
            self.Couleur=c
        except:
            print("Vous devez renseigner une couleur de carte valide !")

    def getNom(self):
        if self.Valeur>1 and self.Valeur<11:
            return str(self.Valeur)
        elif self.Valeur==11:
            return "Valet"
        elif self.Valeur==12:
            return "Dame"
        elif self.Valeur==13:
            return "Roi"
        else:
            return "As"
    
    def getCouleur(self):
        return ['pique','coeur','carreau','trefle'][self.Couleur]
    
class PaquetDeCarte:
    def __init__(self):
        self.contenu=[]
        
    def remplir(self):
        for couleur in range(0,4):
            for valeur in range(1,14):
                self.contenu.append(Carte(couleur,valeur))

    def getCarteAt(self,pos):
        if pos<=52 and pos>=1:
            return self.contenu[pos-1]
        
if __name__=="__main__":
    unPaquet = PaquetDeCarte() 
    unPaquet.remplir() 
    uneCarte = unPaquet.getCarteAt(20) 
    print(uneCarte.getNom() + " de " + uneCarte.getCouleur())