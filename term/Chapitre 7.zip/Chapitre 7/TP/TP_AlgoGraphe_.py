from Classe_Graphe import Graphe
from Classe_File import File
from Classe_Pile import Pile


# 1)
class Sommet:
    def __init__(self,color,name):
        self.__nom=name
        self.__couleur=color
    
    def getNom(self):
        return self.__nom
    
    def getCouleur(self):
        return self.__couleur
    
    def setNom(self,name):
        self.__nom=name
    
    def setCouleur(self,color):
        self.__couleur=color


g1=Graphe()
g1.ajouter_arete("A","B")
g1.ajouter_arete("A","C")
g1.ajouter_arete("A","H")
g1.ajouter_arete("B","I")
g1.ajouter_arete("I","H")
g1.ajouter_arete("I","F")
g1.ajouter_arete("F","G")
g1.ajouter_arete("H","G")
g1.ajouter_arete("G","E")
g1.ajouter_arete("E","C")
g1.ajouter_arete("E","D")
g1.ajouter_arete("D","C")


# 2)
def parcours_largeur_dabord(graphe,s):
    u=None
    v=None
    f=File()
    vus=[]
    f.enfiler(s)
    while not f.vide():
        u=f.defiler()
        if u not in vus:
            vus.append(u)
            for v in graphe.voisins(u):
                if v not in vus:
                    f.enfiler(v)
    return vus

print(parcours_largeur_dabord(g1,"A"))


# 3)
def parcours_profondeur_dabord_iteratif(graphe,s):
    u=None
    v=None
    p=Pile()
    vus=[]
    p.empiler(s)
    while not p.vide():
        u=p.depiler()
        if u not in vus:
            vus.append(u)
            for v in graphe.voisins(u):
                if v not in vus:
                    p.empiler(v)
    return vus

print(parcours_profondeur_dabord_iteratif(g1,"A"))


# 4)
def parcours_profondeur_dabord_recursif(graphe,u,vus=[]):
    if vus==[]:
        vus=[u]
    else:
        vus.append(u)
    for v in graphe.voisins(u):
        if v not in vus:
            graphe.parcours_profondeur_dabord(v,vus)
    return vus

print(parcours_profondeur_dabord_recursif(g1,"A"))

# 5)