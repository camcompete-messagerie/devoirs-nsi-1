from Classe_File import File
from Classe_Pile import Pile

class Graphe:
    def __init__(self):
        self.vois = dict()

    def ajouter_sommet(self, s):
        self.vois[s] = []

    def ajouter_arc(self, s1, s2):   # Orienté
        if s1 not in self.vois:
            self.ajouter_sommet(s1)
        if s2 not in self.vois:
            self.ajouter_sommet(s2)
        self.vois[s1].append(s2)

    def ajouter_arete(self, s1, s2):   # Non orienté
        if s1 not in self.vois:
            self.ajouter_sommet(s1)
        if s2 not in self.vois:
            self.ajouter_sommet(s2)
        self.vois[s1].append(s2)
        self.vois[s2].append(s1)

    def liste_sommets(self):
        return sorted(self.vois)

    def voisins(self, s):
        return self.vois[s]
    
    def parcours_largeur_dabord(self,s):
        u=None
        v=None
        f=File()
        vus=[]
        f.enfiler(s)
        while not f.vide():
            u=f.defiler()
            if u not in vus:
                vus.append(u)
                for v in self.voisins(u):
                    if v not in vus:
                        f.enfiler(v)
        return vus
    
    def parcours_profondeur_dabord(self,u,vus=[]):
        if vus==[]:
            vus=[u]
        else:
            vus.append(u)
        for v in self.voisins(u):
            if v not in vus:
                self.parcours_profondeur_dabord(v,vus)
        return vus
    
    def parcours_profondeur_dabord_iteratif(self,s):
        u=None
        v=None
        p=Pile()
        vus=[]
        p.empiler(s)
        while not p.vide():
            u=p.depiler()
            if u not in vus:
                vus.append(u)
                for v in self.voisins(u):
                    if v not in vus:
                        p.empiler(v)
        return vus
    
    def recherche_cycle(self,s):
        #u=None
        #v=None
        p=Pile()
        vus=[]
        p.empiler(s)
        while not p.vide():
            u=p.depiler()
            if u in vus:
                return True
            else:
                vus.append(u)
            for v in self.voisins(u):
                if v not in vus:
                    p.empiler(v)
        return False
    
    def recherche_chaine(self,start,end,chaine):
        if chaine==[]:
            chaine=[start]
        else:
            chaine.append(start)
        if start==end:
            return chaine
        for v in self.voisins(start):
            if v not in chaine:
                nchemin=self.recherche_chaine(v,end,chaine)
                if nchemin!=None:
                    return nchemin
                else:
                    chaine.pop()
        return None
    
    def recherche_chaine_iteratif(self,start,end):
        p=Pile()
        vus=[]
        p.empiler(start)
        while not p.vide():
            u=p.depiler()
            if u not in vus:
                vus.append(u)
                for v in self.voisins(u):
                    if v==end:
                        vus.append(end)
                        return vus
                    elif v not in vus:
                        p.empiler(v)
        return None