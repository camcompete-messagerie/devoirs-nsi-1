from Classe_Graphe import Graphe

graphe4=Graphe()
graphe4.ajouter_arc(0,1)
graphe4.ajouter_arc(0,2)
graphe4.ajouter_arc(1,2)
graphe4.ajouter_arc(2,0)
graphe4.ajouter_arc(2,1)
graphe4.ajouter_arc(3,1)
graphe4.ajouter_arc(3,2)

# 9)
print("-------------------------------Exercice 9------------------------------")
print(graphe4.parcours_largeur_dabord(0))
print(graphe4.parcours_largeur_dabord(1))
print(graphe4.parcours_largeur_dabord(2))
print(graphe4.parcours_largeur_dabord(3))


# 11)
print()
print("------------------------------Exercice 11------------------------------")
print(graphe4.parcours_profondeur_dabord(0))
print(graphe4.parcours_profondeur_dabord(1))
print(graphe4.parcours_profondeur_dabord(2))
print(graphe4.parcours_profondeur_dabord(3))



# 12 et 13)
print()
print("---------------------------Exercice 12 et 13---------------------------")
for i in range(4):
    for j in range(4):
        if i!=j:
            res=graphe4.recherche_chaine_iteratif(i,j)
            if res==None:
                print(f"Il n'existe pas de chemin pour aller du sommet {i} au sommet {j}.")
            else:
                print(f"Le chemin pour aller du sommet {i} au sommet {j} est : {res}")
    print()


# 14)
print("------------------------------Exercice 14------------------------------")
for i in range(4):
    print(f"Cycle en partant du sommet {i} ? : {graphe4.recherche_cycle(i)}")