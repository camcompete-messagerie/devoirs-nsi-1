###---Exercice 1---###
"""
Voisins de chaque sommet :
A ---> B ; C
B ---> C ; D
C ---> B
D ---> C
"""


###---Exercice 2---###
"""
Voisins de chaque sommet :
A ---> B ; C ; D
B ---> A ; C ; D
C ---> A ; B ; D
D ---> A ; B ; C
"""


###---Exerice 4---###
"""
Degré de chaque sommet du graphe 1 (orienté) :
A : 2
B : 2
C : 1
D : 1

Degré de chaque sommet du graphe 2 (non orienté) :
A : 2
B : 3
C : 3
D : 2
"""


###---Exercice 5---###
def matrice_vers_listes(graphe_matrice):
    graphe_dico={}
    for ligne in range(len(graphe_matrice)):
        graphe_dico[ligne]=[]
        for colonne in range(len(graphe_matrice[ligne])):
            if graphe_matrice[ligne][colonne] == 1:
                graphe_dico[ligne].append(colonne)
    return graphe_dico

graphe1_matrice=[[0,1,1,0],
                 [0,0,1,0],
                 [1,1,0,0],
                 [0,1,1,0]]

print("La liste des successeurs du graphe 1 à partir de sa matrice est :")
print(matrice_vers_listes(graphe1_matrice))


###---Exercice 6---###
def listes_vers_matrice(graphe_dico):
    graphe_matrice=[]
    for ligne in range(len(graphe_dico)):
        graphe_matrice.append([])
        for colonne in range(len(graphe_dico)):
            if colonne in graphe_dico[ligne]:
                graphe_matrice[ligne].append(1)
            else:
                graphe_matrice[ligne].append(0)
    return graphe_matrice

graphe1_successeurs={0:[1, 2], 1:[2], 2:[0, 1], 3:[1, 2]}

print("---------------------------------------------------------------------------")
print("La matrice du graphe 1 à partir de sa liste de successeurs est :")
print(listes_vers_matrice(graphe1_successeurs))


###---Exercice 8---###
class Graphe:
    def __init__(self):
        self.vois = dict()

    def ajouter_sommet(self, s):
        self.vois[s] = []

    def ajouter_arc(self, s1, s2):
        if s1 not in self.vois:
            self.ajouter_sommet(s1)
        if s2 not in self.vois:
            self.ajouter_sommet(s2)
        self.vois[s1].append(s2)

    def ajouter_arete(self, s1, s2):
        if s1 not in self.vois:
            self.ajouter_sommet(s1)
        if s2 not in self.vois:
            self.ajouter_sommet(s2)
        self.vois[s1].append(s2)
        self.vois[s2].append(s1)

    def liste_sommets(self):
        return sorted(self.vois)

    def voisins(self, s):
        return self.vois[s]


graphe1 = Graphe()
graphe1.ajouter_arc(0, 1)
graphe1.ajouter_arc(0, 2)
graphe1.ajouter_arc(1, 2)
graphe1.ajouter_arc(2, 0)
graphe1.ajouter_arc(2, 1)
graphe1.ajouter_arc(3, 1)
graphe1.ajouter_arc(3, 2) 

print("---------------------------------------------------------------------------")
print("La liste de successeurs du graphe 1 à partir de sa version en classe est :")
print(graphe1.vois)


graphe2=Graphe()
graphe2.ajouter_arc(0, 1)
graphe2.ajouter_arc(0, 2)
graphe2.ajouter_arc(0, 3)
graphe2.ajouter_arc(1, 0)
graphe2.ajouter_arc(1, 3)
graphe2.ajouter_arc(2, 3)
graphe2.ajouter_arc(2, 0)
graphe2.ajouter_arc(3, 1)

print("---------------------------------------------------------------------------")
print("La liste de successeurs du graphe 2 à partir de sa version en classe est :")
print(graphe2.vois)


graphe3=Graphe()
graphe3.ajouter_arc("A", "B")
graphe3.ajouter_arc("A", "C")
graphe3.ajouter_arc("A", "D")
graphe3.ajouter_arc("B", "A")
graphe3.ajouter_arc("B", "D")
graphe3.ajouter_arc("C", "A")
graphe3.ajouter_arc("D", "A")
graphe3.ajouter_arc("D", "B")

print("---------------------------------------------------------------------------")
print("La liste de successeurs du graphe 3 à partir de sa version en classe est :")
print(graphe3.vois)