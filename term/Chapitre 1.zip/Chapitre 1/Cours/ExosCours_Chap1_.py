# A faire 1)
def somme_rec(liste):
    if len(liste)==1:
        return liste[0]
    else:
        return liste[0]+somme_rec(liste[1:])

assert somme_rec([2,12,1,8,5,10,20])==58
assert somme_rec([1,2,3,4,5])==15
assert somme_rec([5])==5
assert somme_rec([0])==0


# A faire 2)
from timeit import default_timer as timer
from random import randint

L=[randint(0,100) for i in range(983)]
print("Liste :", L)
print("\n\n___________________A faire___________________")

print("\n-------------------Sommes--------------------")

def somme_it(liste):
    rep=0
    for nb in liste:
        rep+=nb
    return rep

debut=timer()
print("somme_rec(L) =", somme_rec(L))
fin=timer()
print("timer de somme_rec(L) =", fin-debut)
debut=timer()
print("somme_it(L) =", somme_it(L))
fin=timer()
print("timer de somme_it(L) =", fin-debut)
debut=timer()
print("sum(L) =", sum(L))
fin=timer()
print("timer de sum(L) =", fin-debut)


# A faire 3)
print("\n-------------------Minimum-------------------")

def minimum(a,b):
    if a<b:
        return a
    else:
        return b

def miniIt(L):
    mini=L[0]
    for i in range(1,len(L)):
        mini=minimum(mini,L[i])
    return mini

def miniRec(L):
    if len(L)==1:
        return L[0]
    else:
        return minimum(L[0],miniRec(L[1:]))

debut=timer()
print("miniRec(L) =", miniRec(L))
fin=timer()
print("timer de miniRec(L) =", fin-debut)
debut=timer()
print("miniIt(L) =", miniIt(L))
fin=timer()
print("timer de miniIt(L) =", fin-debut)
debut=timer()
print("min(L) =", min(L))
fin=timer()
print("timer de min(L) =", fin-debut)

def autre_decoupage_de_L_rec(L):
    if len(L)==1:
        return L[0]
    else:
        return minimum(autre_decoupage_de_L_rec(L[0:len(L)//2]),autre_decoupage_de_L_rec(L[len(L)//2:]))
    
debut=timer()
print("autre_decoupage_de_L_rec(L) =", autre_decoupage_de_L_rec(L))
fin=timer()
print("timer de autre_decoupage_de_L_rec(L) =", fin-debut)


print("\n\n__________________Exercices__________________")
# 1)
print("\n-------------------Maximum-------------------")

def maxiIt(L):
    maxi=L[0]
    for i in range(1,len(L)):
        maxi=max(maxi,L[i])
    return maxi

def maxiRec(L):
    if len(L)==1:
        return L[0]
    else:
        return max(L[0],maxiRec(L[1:]))

print("maxiIt(L) =", maxiIt(L))
print("maxiRec(L) =", maxiRec(L))

# 2)
print("\n------------------Puissances-----------------")

def puissanceIt(x,n):
    rep=1
    for i in range(n):
        rep=rep*x
    return rep

def puissanceRec(x,n):
    if n==0:
        return 1
    else:
        return x*puissanceRec(x,n-1)

x=randint(0,20)
n=randint(0,3)
print("x =", x, "et n =", n)
print("puissanceIt(x,n) =",puissanceIt(x,n))
print("puissanceRec(x,n) =",puissanceRec(x,n))

# 3)
print("\n-----------------Factorielles----------------")

def factorielleIt(n):
    rep=1
    for i in range(n,0,-1):
        rep*=i
    return rep

def factorielleRec(n):
    if n==0:
        return 1
    else:
        return n*factorielleRec(n-1)

a=randint(0,10)
print("a =", a)
print("factorielleIt(a) =", factorielleIt(a))
print("factorielleRec(a) =", factorielleRec(a))