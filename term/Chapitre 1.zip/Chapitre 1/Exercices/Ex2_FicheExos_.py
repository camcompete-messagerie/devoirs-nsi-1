def moyenne_liste_rec(l,i=0):
    if i==len(l)-1:
        return l[i]/len(l)
    return l[i]/len(l)+moyenne_liste_rec(l,i+1)

liste=[8,17,14,11,15]
print(liste)
print(moyenne_liste_rec(liste))
assert moyenne_liste_rec(liste)==sum(liste)/len(liste)
