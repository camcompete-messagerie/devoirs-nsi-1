# 1)
def nb_diviseurs(j,n):
    if j==1:
        return 1
    elif n%j==0:
        return nb_diviseurs(j-1,n)+1
    else:
        return nb_diviseurs(j-1,n)

print(f"1)\nnb_diviseurs(10,15) : {nb_diviseurs(10,15)}")


# 2)
def somme_diviseurs(j,n):
    if j==1:
        return 1
    elif n%j==0:
        return somme_diviseurs(j-1,n)+j
    else:
        return somme_diviseurs(j-1,n)

print(f"\n2)\nsomme_diviseurs(10,15) : {somme_diviseurs(10,15)}")


# 3)
def est_parfait(n):
    if somme_diviseurs(n,n)==2*n:
        return True
    else:
        return False

print(f"\n3)\nest_parfait(6) : {est_parfait(6)}")
print(f"est_parfait(28) : {est_parfait(28)}")
print(f"est_parfait(15) : {est_parfait(15)}")


# 4)
def est_parfait_rec(n,j=None,s=None):
    if j==None:
        j=n
    if s==None:
        s=0
    if j==1:
        return s+1==2*n
    elif n%j==0:
        return est_parfait_rec(n,j-1,s+j)
    else:
        return est_parfait_rec(n,j-1,s)

print(f"\n4)\nest_parfait_rec(6) : {est_parfait_rec(6)}")
print(f"est_parfait_rec(28) : {est_parfait_rec(28)}")
print(f"est_parfait_rec(15) : {est_parfait_rec(15)}")