# 1)
def syracuse_rec(u,i):
    if i<=0:
        return u
    elif u%2==0:
        return syracuse_rec(u//2,i-1)
    else:
        return syracuse_rec(3*u+1,i-1)

print(syracuse_rec(4,1))
assert syracuse_rec(5,5)==1
assert syracuse_rec(10,7)==4
assert syracuse_rec(276917863,163)==160


# 2)
def tps_vol(u,i):
    pass