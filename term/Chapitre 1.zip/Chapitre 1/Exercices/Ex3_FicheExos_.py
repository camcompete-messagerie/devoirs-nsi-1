def tri_insertion_rec(l,n=None):
    if n==None:
        n=len(l)
    if n<=1:
        return
    tri_insertion_rec(l,n-1)
    if l[n-1]<l[n-2]:
        l[n-1],l[n-2]=l[n-2],l[n-1]
        tri_insertion_rec(l,n-1)

liste=[5,2,3,4,1]
print(liste)
tri_insertion_rec(liste)
print(liste)