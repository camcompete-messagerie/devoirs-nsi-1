# coding: utf-8

#
# Exercice 14 - Rendu de monnaie glouton
#

def glouton(pieces, montant):
    """
    Entrée:
    - pieces est un tableau de valeurs décroissantes
    représentant les types de pièces disponibles.
    - montant est le montant à payer.
    Chaque pièce est supposée disponible en quantité illimitée.
    ------
    Renvoie un tableau des pièces utilisées, par valeur croissante. 
    """
    if montant == 0:
        return []
    else:
        i = 0
        while i < len(pieces):
            if pieces[i]>montant:
                i = i + 1
            else:
                res = glouton(pieces,montant-pieces[i])
                res.append(pieces[i])
                return res


# Test:
print(sorted(glouton([10, 5, 2, 1], 9)) == [2, 2, 5])
print(sorted(glouton([10, 5, 2, 1], 48)) == [1, 2, 5, 10, 10, 10, 10])