def tri_selection_rec(l,i=0):
    if i>=len(l)-1:
        return
    j_min=i
    for j in range(i+1,len(l)):
        if l[j]<l[j_min]:
            j_min=j
    if j_min!=i:
        l[i],l[j_min]=l[j_min],l[i]
    tri_selection_rec(l,i+1)

liste=[5,2,3,4,1]
print(liste)
tri_selection_rec(liste)
print(liste)