# A faire 1)
def hanoi(n,dep,inter,arr):
    if n==0:
        return None
    else:
        hanoi(n-1,dep,arr,inter)
        print("Déplacer le disque {} de la tige {} vers la tige {}.".format(n,dep,arr))
        hanoi(n-1,inter,dep,arr)


# A faire 2)
from timeit import default_timer as timer
from random import randint

n=randint(2,8)
print("n =",n,"\n")

debut=timer()
hanoi(n,"de gauche","du milieu","de droite")
fin=timer()
print("\ntimer de hanoi(n) =", fin-debut,"\n")


# Pour aller un peu plus loin)
def affichage(tours) :
    d = len(tours['départ'])
    i = len(tours['intermédiaire'])
    a = len(tours['arrivée'])
    hauteur = max(d, i, a)
    for h in range(hauteur, 0, -1) :
        if d >= h :
            print( tours['départ'][h-1], end=' ')
        else :
            print(' ', end=' ')
        if i >= h :
            print( tours['intermédiaire'][h-1], end=' ')
        else :
            print(' ', end=' ')
        if a >= h :
            print( tours['arrivée'][h-1])
        else :
            print(' ')
    print('\u2AE0 \u2AE0 \u2AE0')
    print('------------------------------------------------------------')

def Hanoi(n,dep='départ',inter='intermédiaire',arr='arrivée'):
    """
    Calcule et affiche graphiquement les déplacements de n disques des tours de Hanoï.
    Input : dep --> Tige de départ - str.
            inter --> Tige intermédiaire - str.
            arr --> Tige d'arrivée - str.
    """
    if n==0:
        return None
    else:
        Hanoi(n-1,dep,arr,inter)
        anneau_deplace = tours[dep].pop()
        tours[arr].append(anneau_deplace)
        affichage(tours)
        Hanoi(n-1,inter,dep,arr)

n=4
tours = dict()
tours['départ'] = [ j for j in range(n,0,-1) ]
tours['intermédiaire'] = []
tours['arrivée'] = []
Hanoi(n)