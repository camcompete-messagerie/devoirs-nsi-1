import turtle as t

# A faire 1)
def polygoneIt(n,l,a):
    t.ht()
    t.speed(0)
    t.color("blue")
    for i in range(n):
        t.forward(l)
        t.right(a)

polygoneIt(9,80,40)


# A faire 2)
def polygoneRec(n,l,a):
    t.ht()
    t.speed(0)
    t.color("red")
    if n==0:
        #return 0
        pass
    else:
        return t.forward(l),t.left(a),polygoneRec(n-1,l,a)

polygoneRec(9,80,40)