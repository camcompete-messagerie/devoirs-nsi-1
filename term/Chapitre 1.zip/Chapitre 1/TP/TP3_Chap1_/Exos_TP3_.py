from turtle import *
speed(0)
ht()

# A faire 2)
def flocon(n,cote):
    if n==0:
        forward(cote)
    else:
        flocon(n-1,cote/3)
        left(60)
        flocon(n-1,cote/3)
        right(120)
        flocon(n-1,cote/3)
        left(60)
        flocon(n-1,cote/3)

n=6
l=500

penup()
goto(-300,200)
pendown()
flocon(n,l)
right(120)
flocon(n,l)
right(120)
flocon(n,l)

exitonclick()