def bTodecIt(mot,b):
    assert (b>1 and b<37) ,"b doit être compris entre 2 et 36"
    assert (type(mot) == str), "Le nombre n doit être une chaîne de caractères"
    signes="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    resul=0
    p=len(mot)
    for i in range(p):
        resul=resul+signes.index(mot[i])*b**(p-i-1)
    return resul

# A faire 1)
assert bTodecIt("10011",2)==19
assert bTodecIt("4D",16)==77
assert bTodecIt("35",7)==26
assert bTodecIt("B20A",12)==19306


# A faire 2)
def bTodecRec(n,b):
    signes="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    if len(n)==0:
        return 0
    else:
        return signes.index(n[0])*b**(len(n)-1)+bTodecRec(n[1:],b)

assert bTodecRec("10011",2)==19
assert bTodecRec("4D",16)==77
assert bTodecRec("35",7)==26
assert bTodecRec("B20A",12)==19306