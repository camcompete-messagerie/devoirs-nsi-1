# A faire 1)
def est_palindrome_Rec(mot):
    mot=mot.lower()
    if len(mot)<=1:
        return True
    elif mot[0]!= mot[-1]:
        return False
    else:
        return est_palindrome_Rec(mot[1:-1])

print(est_palindrome_Rec("RaDaR"))



# A faire 2)
def est_palindrome_Rec_2(phrase):
    return est_palindrome_Rec("".join(phrase.split()))

print(est_palindrome_Rec_2("Karine alla en Irak"))