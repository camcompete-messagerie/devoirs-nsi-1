# A faire 1)
print("A faire 1)")
print(bin(77)[2:]) # Affiche 77 en base 2
print(oct(77)[2:]) # Affiche 77 en base 8
print(hex(77)[2:]) # Affiche 77 en base 16


# A faire 2)
def decTobRec(n,b):
    signes="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    if n==0:
        return ""
    else:
        return decTobRec(n//b,b)+signes[n%b]

print("\nA faire 2)")
print(decTobRec(77,2))
print(decTobRec(77,8))
print(decTobRec(77,16))
print(decTobRec("B20A","7"))