# A faire 1
d={chr(i+65): chr((i+13)%26+65) for i in range(26)}
#print(d)

phrase="BONJOUR, COMMENT ALLEZ-VOUS"
phrase_codee=""
for car in phrase:
    if car in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
        phrase_codee+=d[car]
    else:
        phrase_codee+=car

print(phrase_codee)
print()


# A faire 2
message="Bonjour, comment allez-vous ?"
cle="mystère"

def chiffre(message,key):
    c=[]
    n=len(message)
    m=len(key)
    j=0
    for i in range(n):
        c.append(chr(ord(message[i])^ord(key[j])))
        j=(j+1)%m
    return c

message_chiffre=chiffre(message,cle)
print(message_chiffre)
print()


# A faire 3
def dechiffre(message,key):
    message_dechiffre=""
    m=len(key)
    j=0
    for i in range(len(message)):
        message_dechiffre+=chr(ord(message[i])^ord(key[j]))
        j=(j+1)%m
    return message_dechiffre

print(dechiffre(message_chiffre,cle))
print()


# A faire 4
d4={chr(i+65): chr((i+9)%26+65) for i in range(26)}
hello="HELLO LES QUICHES"
hello_code=""
for car in hello:
    if car in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
        hello_code+=d4[car]
    else:
        hello_code+=car

print(hello_code)

d4bis={chr(i+65): chr((i+17)%26+65) for i in range(26)}
hello_decode=""
for car in hello_code:
    if car in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
        hello_decode+=d4bis[car]
    else:
        hello_decode+=car

print(hello_decode)


# A faire 5
