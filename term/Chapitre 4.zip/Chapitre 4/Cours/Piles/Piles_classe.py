class Pile:
    def __init__(self):
        self.P=[]
    
    def vide(self):
        return self.P==[]
    
    def depiler(self):
        assert not self.vide(), "Pile vide"
        return self.P.pop()
    
    def empiler(self,x):
        self.P.append(x)

    ###---Exercice 2---###
    def taille(self):
        return len(self.P)
    
    def sommet(self):
        return self.P[-1]



###---A faire 2---###
if __name__=="__main__":
    p=Pile()
    print(p.vide())
    for i in range(5):
        p.empiler(2*i)
    print(p.vide())
    a=p.depiler()
    print(a)
    print(p.taille())
    print(p.sommet())