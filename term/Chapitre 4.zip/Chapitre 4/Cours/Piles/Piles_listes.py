def pile():
    return []

def vide(p):
    return p==[]

def empiler(p,x):
    p.append(x)

def depiler(p):
    assert not vide(p), "! Pile vide !"
    return p.pop()


###---Exercice 1---###
def taille(p):
    return len(p)

def sommet(p):
    return p[-1]



###---A faire 1---###
if __name__=="__main__":
    p=pile()
    print(vide(p))
    for i in range(5):
        empiler(p,2*i)
    print(vide(p))
    a=depiler(p)
    print(a)
    print(taille(p))
    print(sommet(p))