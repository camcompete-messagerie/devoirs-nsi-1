def file():
    return []

def vide(f):
    return f==[]

def enfiler(f,x):
    return f.append(x)

def defiler(f):
    assert not vide(f), "file vide"
    return f.pop(0)


###---A faire 1---###
f=file()
for i in range(5):
    enfiler(f,2*i)
print(f)
a=defiler(f)
print(a)
print(f)
print(vide(f))


###---Exercice 1---###
def remplissage(f):
    return len(f)

def tete(f):
    return f[0]

print(remplissage(f))
print(tete(f))