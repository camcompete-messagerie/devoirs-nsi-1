###---A faire 1---###

def vide():
    return None

def cons(x,L):
    return(x,L)

def ajouteEnTete(L,x):
    return cons(x,L)

def supprEnTete(L):
    return (L[0],L[1])

def estVide(L):
    return L is None

def compte(L):
    if estVide(L):
        return 0
    return 1 + compte(L[1])

if __name__=='__main__':
    print("----------------------------------------------#####-A faire 1-#####--------------------------------------------------")
    nil=vide()
    print(estVide(nil))
    L=cons(5, cons(4, cons(3, cons(2, cons(1, cons(0,nil))))))
    print(estVide(L))
    print(compte(L))
    L = ajouteEnTete(L,6)
    print(compte(L))
    x, L=supprEnTete(L)
    print(x)
    print(compte(L))
    x, L=supprEnTete(L)
    print(x)
    print(compte(L))