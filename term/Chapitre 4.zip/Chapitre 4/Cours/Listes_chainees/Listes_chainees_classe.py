###---A faire 2---###

class Cellule:
    def __init__(self, tete, queue):
        self.car = tete
        self.cdr = queue

class Liste:
    def __init__(self, c):
        self.cellule = c
    
    def estVide(self):
        return self.cellule is None
    
    def car(self):
        assert not(self.cellule is None), 'Liste vide'
        return self.cellule.car
    
    def cdr(self):
        assert not(self.cellule is None), 'Liste vide'
        return self.cellule.cdr
    
    def longueurListe(self):
        n = 0
        while not(self.estVide()):
            n += 1
            self = self.cdr()
        return n
    
    def listeElements(self):
        t = []
        while not(self.estVide()):
            t.append(self.car())
            self = self.cdr()
        return t
    
    def ajouteEnTete(self,nb):
        c=Cellule(6,cons(self.car(),self.cdr()))
        self.cellule=c
        return self
        """c=Cellule(nb,self.cellule)
        self.cellule=c"""
    
    def supprEnTete(self,liste):
        return 
    
def cons(tete, queue):
    return Liste(Cellule(tete, queue))


if __name__=='__main__':
    print("----------------------------------------------#####-A faire 2-#####--------------------------------------------------")
    nil=Liste(None)
    L = cons(5, cons(4, cons(3, cons(2, cons(1, cons(0,nil))))))
    print(L.estVide())
    print(L.car())
    print(L.cdr().car())
    print(L.cdr().cdr().car())


###---A faire 3---###

if __name__=='__main__':
    print("----------------------------------------------#####-A faire 3-#####--------------------------------------------------")
    L = cons(5, cons(4, cons(3, cons(2, cons(1, cons(0,nil))))))
    print(L.longueurListe())
    print(L.listeElements())
    print("La méthode longueurListe() renvoie la longueur de la liste sur laquelle on applique cette méthode.")
    print("La méthode listeElements() renvoie la liste (type list) des éléments de la liste sur laquelle on applique la méthode.")


###---A faire 4---###

if __name__=='__main__':
    print("----------------------------------------------#####-A faire 4-#####--------------------------------------------------")
    L = cons(5, cons(4, cons(3, cons(2, cons(1, cons(0,nil))))))
    print(L.listeElements())
    L=cons(6,L)
    print(L.listeElements())
    print("Cette instruction rajoute la valeur passée en paramètre (ici 6) au début de la liste.")


###---A faire 5---###

if __name__=='__main__':
    print("----------------------------------------------#####-A faire 5-#####--------------------------------------------------")
    L = cons(5, cons(4, cons(3, cons(2, cons(1, cons(0,nil))))))
    L.ajouteEnTete(6)
    print(L.listeElements())


###---A faire 6---###
if __name__=='__main__':
    print("----------------------------------------------#####-A faire 6-#####--------------------------------------------------")
print("1) La première valeur de L est affectée à x.")
print("2) ")


###---A faire 7---###
if __name__=='__main__':
    print("----------------------------------------------#####-A faire 7-#####--------------------------------------------------")
    L = cons(5, cons(4, cons(3, cons(2, cons(1, cons(0,nil))))))
    L.supprEnTete(L)
    print(L.listeElements())