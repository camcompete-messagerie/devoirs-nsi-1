class FileBornee:
    def __init__(self,n):
        self.tab=[None]*n
        self.premier=0
        self.suivant=0
        self.taille=0
        self.capacite=n
    
    def est_vide(self):
        return self.taille==0
    
    def est_pleine(self):
        return self.taille==self.capacite
    
    def ajouter(self,v):
        if self.est_pleine():
            raise IndexError("! File pleine !")
        else:
            if self.suivant+1>=self.capacite:
                self.suivant=0
            else:
                self.suivant+=1
            self.tab[self.suivant-1]=v
            self.taille+=1
    
    def retirer(self):
        if self.est_vide():
            raise IndexError("! File vide !")
        else:
            val=self.tab[self.premier]
            self.tab[self.premier]=None
            if self.premier+1>=self.capacite:
                self.premier=0
            else:
                self.premier+=1
            self.taille-=1
        return val
        
    def __str__(self):
        if self.est_vide():
            return "! File vide !"
        else:
            res="premier <- "+str(self.tab[self.premier])+" <- "
            i=(self.premier+1)%self.capacite
            while i!=self.suivant:
                res+=str(self.tab[i])+" <- "
                if i==self.capacite-1:
                    i=0
                else:
                    i+=1
            res+="dernier"
            return res


fb=FileBornee(5)
fb.ajouter(5)
fb.ajouter(9)
fb.ajouter(1)
fb.ajouter(8)
fb.retirer()
fb.ajouter(11)
fb.ajouter(15)
print(fb)