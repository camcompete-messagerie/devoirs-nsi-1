from Piles_classe import *
from copy import deepcopy

class File2:
    def __init__(self):
        self.defausse=Pile()
        self.pioche=Pile()
    
    def est_vide(self):
        return (self.defausse.vide() and self.pioche.vide())
    
    def taille(self):
        return self.defausse.taille()+self.pioche.taille()
    
    def enfiler(self,v):
        self.defausse.empiler(v)
    
    def defiler(self):
        if self.pioche.vide() and self.defausse.vide():
            raise IndexError("! File vide !")
        elif self.pioche.vide() and self.defausse.vide()==False:
            for i in range(self.defausse.taille()):
                self.pioche.empiler(self.defausse.depiler())
            return self.pioche.depiler()
        else:
            return self.pioche.depiler()
    
    def __str__(self):
        res="premier <- "
        D=deepcopy(self.defausse)
        P=deepcopy(self.pioche)
        if self.est_vide():
            raise IndexError("! File vide !")
        else:
            for i in range(self.taille()):
                res+=str(self.defiler())+" <- "
            res+="dernier"
            self.defausse=D
            self.pioche=P
            return res
        """elif self.defausse.vide() and self.pioche.vide()==False:
            while not self.pioche.vide():
                res+=str(self.pioche.depiler())+" <- "
            res+="dernier"
            return res
        elif self.pioche.vide() and self.defausse.vide()==False:
            for i in range(self.defausse.taille()):
                res+=str(self.defiler())+" <- "
            res+="dernier"
            return res
        elif self.pioche.vide()==False and self.defausse.vide()==False:
            pass"""


f=File2()
f.enfiler(0)
f.enfiler(2)
f.enfiler(5)
f.defiler()
f.enfiler(1)
f.defiler()
f.enfiler(7)
f.defiler()
f.defiler()
f.enfiler(4)
f.defiler()
f.enfiler(8)
f.enfiler(9)
f.defiler()
f.enfiler(20)
f.enfiler(21)

print(f)
print(f)