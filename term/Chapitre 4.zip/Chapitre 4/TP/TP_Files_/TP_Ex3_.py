from Listes_chainees_classe import Cellule

class File:
    def __init__(self):
        self.premier=None
        self.dernier=None
    
    def est_vide(self):
        pass
    
    def enfiler(self,v):
        self.dernier.cdr=Cellule(v,None)
    
    def defiler(self):
        if self.est_vide():
            raise IndexError("! File vide !")
        pass
    
    def __str__(self):
        if self.est_vide():
            raise IndexError("! File vide !")
        pass