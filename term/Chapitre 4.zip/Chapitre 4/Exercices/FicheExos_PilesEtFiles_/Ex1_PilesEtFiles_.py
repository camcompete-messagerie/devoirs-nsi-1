from Piles_classe import Pile
from ExsPreliminaires_PilesEtFiles_Jules_Rollier import creation_file

def inverser_file(f):
    p=Pile()
    for i in range(f.remplissage()):
        p.empiler(f.defiler())
    for i in range(p.taille()):
        f.enfiler(p.depiler())
    return f

if __name__=="__main__":
    F=creation_file(10)
    print(F)
    print(inverser_file(F))
