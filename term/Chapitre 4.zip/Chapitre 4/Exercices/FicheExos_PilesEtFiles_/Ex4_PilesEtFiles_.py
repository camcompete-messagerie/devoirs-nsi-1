from Piles_classe import Pile
from ExsPreliminaires_PilesEtFiles_Jules_Rollier import creation_pile

def tri_pile_parite(p):
    t_p=p.taille()
    p_pair=Pile()
    p_impair=Pile()
    while not p.vide():
        if p.sommet()%2==0:
            p_pair.empiler(p.depiler())
        else:
            p_impair.empiler(p.depiler())
    while not p_impair.vide():
        p.empiler(p_impair.depiler())
    while not p_pair.vide():
        p.empiler(p_pair.depiler())
    return p

if __name__=="__main__":
    P=creation_pile(10)
    print(P)
    print(tri_pile_parite(P))
