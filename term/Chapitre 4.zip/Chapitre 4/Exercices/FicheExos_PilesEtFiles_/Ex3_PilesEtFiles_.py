from Files_classe import File
from ExsPreliminaires_PilesEtFiles_Jules_Rollier import creation_file

def tri_file_parite(f):
    t_f=f.remplissage()
    f_pair=File()
    f_impair=File()
    while not f.vide():
        if f.tete()%2==0:
            f_pair.enfiler(f.defiler())
        else:
            f_impair.enfiler(f.defiler())
    while not f_pair.vide():
        f.enfiler(f_pair.defiler())
    while not f_impair.vide():
        f.enfiler(f_impair.defiler())
    return f

if __name__=="__main__":
    F=creation_file(10)
    print(F)
    print(tri_file_parite(F))
