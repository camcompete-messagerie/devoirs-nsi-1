from Piles_classe import Pile
from Files_classe import File
from random import randint


def creation_file(n):
    f=File()
    for i in range(n):
        f.enfiler(randint(0,100))
    return f

def creation_pile(n):
    p=Pile()
    for i in range(n):
        p.empiler(randint(0,100))
    return p

if __name__=="__main__":
    print(creation_file(10))
    print(creation_pile(10))