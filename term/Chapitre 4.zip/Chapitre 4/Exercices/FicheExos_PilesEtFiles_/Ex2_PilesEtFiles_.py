from Piles_classe import Pile
from ExsPreliminaires_PilesEtFiles_Jules_Rollier import creation_pile

def inverser_pile(p):
    p_bis=Pile()
    p_ter=Pile()
    while not p.vide():
        p_bis.empiler(p.depiler())
    while not p_bis.vide():
        p_ter.empiler(p_bis.depiler())
    while not p_ter.vide():
        p.empiler(p_ter.depiler())
    return 

if __name__=="__main__":
    P=creation_pile(10)
    print(P)
    print(inverser_pile(P))
