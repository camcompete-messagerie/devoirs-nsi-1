from ExsPreliminaires_PilesEtFiles_Jules_Rollier import creation_pile
from Ex2_PilesEtFiles_Jules_Rollier import inverser_pile


def supression_queue_pile(p):
    inverser_pile(p)
    p.depiler()
    inverser_pile(p)
    return p

if __name__=="__main__":
    P=creation_pile(10)
    print(P)
    print(supression_queue_pile(P))
