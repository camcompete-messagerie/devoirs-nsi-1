from ExsPreliminaires_PilesEtFiles_Jules_Rollier import creation_file
from Ex1_PilesEtFiles_Jules_Rollier import inverser_file


def supression_queue_file(f):
    inverser_file(f)
    f.defiler()
    inverser_file(f)
    return f

if __name__=="__main__":
    F=creation_file(10)
    print(F)
    print(supression_queue_file(F))