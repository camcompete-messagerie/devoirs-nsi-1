from Files_classe import *
from random import randint,choice

def croisement(f1,f2):
    f3=File()
    while not f1.vide() or not f2.vide():
        if f1.vide():
            while not f2.vide():
                f3.enfiler(f2.defiler())
        elif f2.vide():
            while not f1.vide():
                f3.enfiler(f1.defiler())
        elif f1.tete()==1:
            f3.enfiler(f1.defiler())
            if f2.tete()==0:
                f2.defiler()
        elif f1.tete()==0:
            if f2.tete()==2:
                f3.enfiler(f2.defiler())
                f1.defiler()
            elif f2.tete()==0:
                f1.defiler()
                f2.defiler()
                f3.enfiler(0)
    return f3


print("----------------------------------Exemple TD----------------------------------")

f1=File()
f1.enfiler(0)
f1.enfiler(1)
f1.enfiler(1)
f1.enfiler(0)
f1.enfiler(1)
f2=File()
f2.enfiler(0)
f2.enfiler(2)
f2.enfiler(2)
f2.enfiler(2)
f2.enfiler(0)
f2.enfiler(2)
f2.enfiler(0)
print(f"R1 : {f1}")
print(f"R2 (STOP) : {f2}")
print(f"R3 : {croisement(f1,f2)}")

print("----------------------------------Aleatoire 1---------------------------------")

def croisement_aleatoire():
    f3=File()
    f4=File()
    for i in range(randint(3,8)):
        f3.enfiler(choice((0,1)))
    for i in range(randint(5,10)):
        f4.enfiler(choice((0,2)))
    print(f"R1 : {f3}")
    print(f"R2 (STOP) : {f4}")
    print(f"R3 : {croisement(f3,f4)}")
    return

croisement_aleatoire()

print("----------------------------------Aleatoire 2---------------------------------")

croisement_aleatoire()

print("----------------------------------Aleatoire 3---------------------------------")

croisement_aleatoire()