from Piles_classe import *
from random import randint

###---A faire 1---###
def decToBin(n):
    p=Pile()
    if n==0:
        return "0"
    while n!=0:
        p.empiler(str(n%2))
        n//=2
    L=""
    for car in p.P:
        L=car+L
    return L

print(f"255 (base 10) ---> {decToBin(255)} (base 2/binaire).")

assert decToBin(0)=="0"
assert decToBin(10)=="1010"
assert decToBin(77)=="1001101"
assert decToBin(240)=="11110000"


###---A faire 2---###
def baseConverter(n,b):
    p=Pile()
    alphabet="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    if n==0:
        return "0"
    while n!=0:
        p.empiler(alphabet[n%b])
        n//=b
    L=""
    for car in p.P:
        L=car+L
    return L

print(f"255 (base 10) ---> {baseConverter(255,16)} (base 16).")

assert baseConverter(0,randint(2,36))=="0"
assert baseConverter(10,2)=="1010"
assert baseConverter(240,16)=="F0"
assert baseConverter(240,8)=="360"