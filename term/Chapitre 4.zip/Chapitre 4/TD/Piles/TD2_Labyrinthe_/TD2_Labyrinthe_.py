###---A faire 1---###
laby=[[0,1,0,0,0,0],
      [0,1,1,1,1,0],
      [0,1,0,1,0,0],
      [0,1,0,1,1,0],
      [0,1,1,0,1,0],
      [0,0,0,0,1,0]]

lignes=len(laby)
colonnes=len(laby[0])


###---A faire 2---###
from copy import deepcopy

T=deepcopy(laby)
T[3][2]="hello"

for ligne in laby:
    print(ligne)
print("-------------------------------")
for ligne in T:
    print(ligne)


###---A faire 3---###
def voisins(T,v):
    """
    Renvoie la liste des cases chemins (pas les murs) voisines à la case v dans le tableau T.
    Input : T ---> tableau (labyrinthe) sur lequel on travaille - list de list.
            v ---> cordonnées (de la forme (ligne,colonne)) de la case dont on souhaite connaître les cases chemins voisines - tuple.
    Output : V ---> liste des cases chemins voisines à la case v.
    """
    V=[]
    i,j=v[0],v[1]
    for a in (-1,1):
        if 0<=i+a<lignes:
            if T[i+a][j]==1:
                V.append((i+a,j))
        if 0<=j+a<colonnes:
            if T[i][j+a]==1:
                V.append((i,j+a))
    return V

print("-------------------------------")
print(voisins(laby,(0,1)))


###---A faire 6---###
from Piles_classe import *
def parcours(laby,entree,sortie):
    T=deepcopy(laby)
    p=Pile()
    v=entree
    T[v[0]][v[1]]=-1
    recherche=True
    while recherche:
        vois=voisins(T,v)
        if vois==[]:
            if p.vide():
                return False
            else:
                v=p.depiler()
        else:
            p.empiler(v)
            v=vois[0]
            T[v[0]][v[1]]=-1
            if v==sortie:
                p.empiler(v)
                recherche=False
    return p

print("-------------------------------")
print(parcours(laby,(0,1),(5,4)))