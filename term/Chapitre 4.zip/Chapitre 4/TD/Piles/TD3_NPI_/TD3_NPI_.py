from Piles_classe import *

###---A faire 1---###

def convNPI(expr):
    p=Pile()
    for car in expr:
        if type(car) in (int,float):
            p.empiler(car)
        elif car in ("+","-","*","/"):
            try:
                sommet=p.depiler()
                sous_sommet=p.depiler()
                p.empiler(eval(str(sous_sommet)+car+str(sommet)))
            except:
                print("! L'expression au format NPI est mal écrite !")
                break
        elif car in ("^","V","abs"):
            if car=="^":
                try:
                    sommet=p.depiler()
                    sous_sommet=p.depiler()
                    p.empiler(sous_sommet**sommet)
                except:
                    print("! L'expression au format NPI est mal écrite !")
                    break
            elif car=="V":
                try:
                    sommet=p.depiler()
                    p.empiler(sommet**0.5)
                except:
                    print("! L'expression au format NPI est mal écrite !")
                    break
            elif car=="abs":
                try:
                    sommet=p.depiler()
                    p.empiler(abs(sommet))
                except:
                    print("! L'expression au format NPI est mal écrite !")
                    break
    try:
        return p.sommet()
    except:
        return "Veuillez saisir à nouveau votre expression en respectant le format."


print(convNPI([3,4,"+",2,"*",3,"^"]))
print(convNPI([6,7,"*",7,"+","V"]))


###---A faire 2---###
"""
def verifNPI(expr):
    for car in expr:
        
"""