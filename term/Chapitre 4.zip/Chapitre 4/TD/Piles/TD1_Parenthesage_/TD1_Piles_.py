from Piles_classe import *

def verification(expr):
    p=Pile()
    for car in expr:
        if car=="(":
            p.empiler("(")
        elif car==")" and not p.vide():
            p.depiler()
        else:
            continue
    if p.vide():
        print("L'expression est correctement parenthésée.")
    else:
        print("L'expression est mal parenthésée.")

