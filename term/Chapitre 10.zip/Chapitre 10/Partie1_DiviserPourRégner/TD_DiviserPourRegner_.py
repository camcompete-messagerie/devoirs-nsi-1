# A faire 1
def recherche_element(l,x,d,f):
    if d==f:
        return l[d]==x
    m=(d+f)//2
    return recherche_element(l,x,d,m) or recherche_element(l,x,m+1,f)

L=[95,28,36,52,85,56,34,59,17,26,16,25,69,98,4,85,81,48,11,57]

print(recherche_element(L,98,0,19))
print()


# A faire 2
def recherche_max(l):
    if len(l)==1:
        return l[0]
    else:
        g=recherche_max(l[:(len(l)//2)])
        d=recherche_max(l[(len(l)//2):])
        if g>d:
            return g
        else:
            return d

print(recherche_max(L))
print()


# A faire 3
def recherche_dicho(l,x,d,f):
    if d>f:
        return False
    m=(d+f)//2
    if l[m]==x:
        return m
    elif x<l[m]:
        return recherche_dicho(l,x,d,m-1)
    else:
        return recherche_dicho(l,x,m+1,f)

print("L'entier recherché est à l'indice ",recherche_dicho(sorted(L),59,0,19),".",sep="")