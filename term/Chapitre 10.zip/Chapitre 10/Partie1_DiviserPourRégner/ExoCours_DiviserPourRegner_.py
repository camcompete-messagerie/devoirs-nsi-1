# A faire 1
from timeit import default_timer as timer

def expo_rec(x,n):
    if n<1:
        return 1
    else:
        return x*expo_rec(x,n-1)

d=timer()
expo_rec(2,500)
f=timer()
print(f-d)
print("Une erreur de récursion se produit pour n>982")
print()


# A faire 2
def expo_dr(x,n):
    if n<1:
        return 1
    else:
        if n%2==0:
            return expo_dr(x*x,n//2)
        else:
            return expo_dr(x*x,n//2)*x

d2=timer()
expo_dr(2,500)
f2=timer()
print(f2-d2)
print("Le deuxième programme est donc bien plus rapide.")
print()

print(expo_dr(2,1000))