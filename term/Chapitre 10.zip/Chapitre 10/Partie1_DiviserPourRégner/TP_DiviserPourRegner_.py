# A faire 1


# A faire 2


# A faire 3
def fusion(T1,T2):
    if T1==[]:
        return T2
    if T2==[]:
        return T1
    if T1[0]<T2[0]:
        return [T1[0]]+fusion(T1[1:],T2)
    else:
        return [T2[0]]+fusion(T1,T2[1:])

def trifusion(T):
    if len(T)<=1:
        return T
    else:
        T1=T[:(len(T)//2)]
        T2=T[(len(T)//2):]
        return fusion(trifusion(T1),trifusion(T2))


# A faire 4
from random import randint
T=[randint(0,100) for i in range(100)]
print("La liste T de départ est :")
print(T)
print("La liste T triée par fusion est :")
print(trifusion(T))

assert [1,2,3,4,5]==trifusion([1,2,3,4,5])