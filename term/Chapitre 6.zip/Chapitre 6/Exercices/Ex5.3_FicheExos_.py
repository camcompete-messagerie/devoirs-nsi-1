from multiprocessing import Process, Lock 
import time 
def ma_fonction(lock, indice): 
    #lock.acquire() 
    print("Bonjour", indice) 
    time.sleep(1) 
    print("Au revoir", indice) 
    print("*"*50) 
    #lock.release() 
if __name__ == '__main__': 
    print("Bonjour depuis le programme principal !") 
    lock=Lock() 
    for indice in range(10): 
        Process(target=ma_fonction, args=(lock,indice)).start() 
    print("Au revoir depuis le programme principal !")

# La classe Lock() est un bloquage qui permet de gérer l'accès à une ressource afin qu'un seul processus ne soit autorisé à l'utiliser.
# La méthode acquire permet à un processus de se munir d'une ressource et de la "bloquer" pour lui seul.
# La méthode release libère la ressource utilisée par un processus en la "dévérouillant".


# Le nouveau comportement est désordonné. Le résultat du code est plusieurs lignes déstructurées.
# Chaque processus vient demander une ressource qui est déjà utilisée par un autre processus.