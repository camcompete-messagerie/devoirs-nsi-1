###---Exercice 5---###

# 1)
from multiprocessing import * 
import os 
def info(message): 
    print(message) # Affiche la tâche à exécuter du processus
    print("process id : ", os.getpid()) # Affiche le PID du processus
    print("parent process id : ", os.getppid()) # Affiche le PPID du processus
    print("Nom du processus :", current_process().name) # Affiche le nom du processus
    print("*"*30) 
if __name__ == '__main__': 
    info("Bonjour depuis le programme principal !") # Affiche la tâche à exécuter et les informations du processus de bienvenue principal
    p1=Process(target=info, name="Alice", args=("Bonjour depuis le  programme d'Alice!",)) # Crétion du processus de nom "Alice"
    p2=Process(target=info, name="Bob", args=("Bonjour depuis le programme de Bob!",)) # Crétion du processus de nom "Bob"
    p1.start() # Exécution du processus de nom "Alice"
    p2.start() # Exécution du processus de nom "Bob"
    p1.join() 
    p2.join() 
    info("Au revoir depuis le programme principal !") # Affiche la tâche à exécuter et les informations du processus de fin principal

# Ce code exécute 4 processus et affiche leur résultat, PID, PPID et nom.