from multiprocessing import * 
import os 

# 2)
def info2(message):
    print(message)
    print("process id :", os.getpid())
    print("parent process id :", os.getppid())
    print("Nom du processus :", current_process().name)
    print("*"*30) 
if __name__ == '__main__':
    info2("Bonjour depuis le programme principal !")
    messages=["Bonjour depuis le programme d'Alice!","Bonjour depuis le programme de Bob!"]
    pool=Pool(3)
    pool.map(info2,messages)
    info2("Au revoir depuis le programme principal !")

# Les processus s'entremêlent contrairement à ceux du 1).

"""
- Parallélisme : technique d’exécution où plusieurs tâches sont exécutées en même temps en utilisant plusieurs coeurs du processeur.

- Multithreading : technique de programmation qui consiste à diviser un programme en plusieurs threads qui s’exécutent
  concurremment (en s'enchaînant rapidement les uns à la suite des autres) au sein du même processus.
"""